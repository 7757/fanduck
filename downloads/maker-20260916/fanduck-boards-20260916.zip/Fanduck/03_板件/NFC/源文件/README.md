# NFC当前KiCad入口

本目录只保留两种当前制造板型：

1. `Microduck_NFC_Rigid_Controller_Head_v0_4.kicad_sch/.kicad_pcb`：52×57×0.8 mm四层刚板，包含CLRC663主控和55×50 mm头部线圈。
2. `Microduck_NFC_Bill_FPC_v0_9.kicad_pcb/.kicad_dru`：65×18 mm线圈区、50 mm中心线L形R5尾线的鸭嘴FPC。

`footprints/`、`fp-lib-table`和`sym-lib-table`是当前工程依赖。`刚板源文件说明.md`和`FPC源文件说明.md`说明清晰命名副本如何从生产脚本输入得到。

KiCad 10.0.6重新检查：刚板PCB DRC 0、未连接0；FPC DRC 0、未连接0。刚板原理图仍有20项警告和79项元数据/封装一致性告警，主要来自旧描述字段和本机库映射，不得把它们隐瞒为“全部0”。完整报告在全面交接包中。
