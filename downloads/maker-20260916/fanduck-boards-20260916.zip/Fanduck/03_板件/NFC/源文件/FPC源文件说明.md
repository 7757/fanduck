# NFC鸭嘴FPC源文件说明

`Microduck_NFC_Bill_FPC_v0_9.kicad_pcb`是实际工厂Gerber所对应的当前FPC源文件复核副本。它只按原生产脚本把标题栏和丝印中的`v0.8 / DO NOT ORDER`提升为`v0.9 / FIRST ARTICLE`；铜线、触点、板框、补强层、背胶层和R5转弯几何未改。

对照工厂文件时，以`../manufacturing/NFC_TWO_OBJECT_FIRST_ARTICLE_QUOTE_v0_5/Microduck_NFC_Bill_FPC_v0_9_GERBER.zip`为准。
