# Banana电池触点转接裸板：当前v0.3

当前KiCad入口为`banana_power_contact.kicad_sch/.kicad_pcb/.kicad_pro`。板框46×7.5×1.6 mm，2层双面2 oz；两枚Harwin `H2183-05`中心距33.8 mm，F1为`1206SFS800F/24` 8 A工程候选，J2用AWG16手焊出线。

嘉立创订单`Y8`只生产5片裸PCB。当前生产文件在`manufacturing/v0.3/`。触点、保险和线材都不由本单贴装。

KiCad 10.0.6重新检查为ERC 0、PCB DRC 0、未连接0、原理图-PCB一致性0。真实NEEWER触点极性、夹持、插入深度、压降、保险选择和温升仍待实物验证，状态`DO NOT POWER`。
