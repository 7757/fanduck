#!/usr/bin/env python3
"""Create a dimensional-only reverse-mounted H2183-05 STEP proxy.

Coordinate contract for the top-side KiCad footprint:

* PCB top face: Z = 0.00 mm
* PCB bottom/battery face: Z = -1.60 mm
* mating tip: Z = -11.45 mm (9.85 mm below the PCB bottom)
* short swaged tail: Z = +0.40 mm nominal

The official drawing supplies the lengths and diameters; the simple cylinders
below intentionally omit manufacturing detail and tolerance geometry.
"""

from pathlib import Path

import FreeCAD as App
import Part


HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "Harwin_H2183_05_reverse_mount_proxy.step"
ASSEMBLY_OUTPUT = HERE / "banana_power_contact_v0.3.step"

doc = App.newDocument("Harwin_H2183_05_reverse_mount_proxy")

# Ø1.75 mm brass pin, total B=11.85 mm.  Reversed so the 9.85 mm catalogued
# above-PCB height projects toward the battery from our PCB bottom face.
pin = Part.makeCylinder(0.875, 11.85, App.Vector(0, 0, -11.45))

# Nominal flange: official family drawing gives Ø2.25 maximum body and
# 0.30-0.40 mm flange thickness.  Use mid-tolerance 0.35 mm.
flange = Part.makeCylinder(1.125, 0.35, App.Vector(0, 0, -1.95))

part = doc.addObject("PartDesign::Feature", "H2183_05_PROXY")
part.Label = "H2183-05 REVERSE-MOUNT DIMENSIONAL PROXY ONLY"
part.Shape = pin.fuse(flange)
doc.recompute()
Part.export([part], str(OUTPUT))
print(OUTPUT)

# Deterministic dimensional assembly.  This is intentionally simple but keeps
# the critical board, hole and reverse-mounted pin geometry in one STEP.
board_shape = Part.makeBox(46.0, 7.5, 1.6, App.Vector(0, 0, -1.6))
for x, y, diameter in (
    (6.10, 3.05, 1.85),
    (39.90, 3.05, 1.85),
    (20.50, 3.05, 1.80),
    (25.50, 3.05, 1.80),
):
    cutter = Part.makeCylinder(diameter / 2.0, 2.0, App.Vector(x, y, -1.8))
    board_shape = board_shape.cut(cutter)

board = doc.addObject("PartDesign::Feature", "CONTACT_PCB")
board.Label = "46x7.5x1.6 CONTACT PCB"
board.Shape = board_shape

for name, x in (("BT1_POS", 6.10), ("BT2_NEG", 39.90)):
    contact = doc.addObject("PartDesign::Feature", name)
    contact.Label = f"{name} H2183-05 REVERSE"
    placed = part.Shape.copy()
    placed.translate(App.Vector(x, 3.05, 0))
    contact.Shape = placed

# Fuse body is a fit-only envelope; exact manufacturer STEP remains represented
# by KiCad when opening the PCB project.
fuse = doc.addObject("PartDesign::Feature", "F1_ENVELOPE")
fuse.Label = "F1 1206SFS ENVELOPE"
fuse.Shape = Part.makeBox(3.2, 1.6, 0.65, App.Vector(10.65, 2.25, 0))

doc.recompute()
Part.export([board, doc.getObject("BT1_POS"), doc.getObject("BT2_NEG"), fuse], str(ASSEMBLY_OUTPUT))
print(ASSEMBLY_OUTPUT)
