#!/usr/bin/env python3
"""Verify critical bounding boxes in the generated contact STEP files."""

from pathlib import Path

import Part


HERE = Path(__file__).resolve().parent


def near(actual: float, expected: float, tolerance: float = 0.002) -> None:
    if abs(actual - expected) > tolerance:
        raise RuntimeError(f"STEP bound {actual:.6f} != {expected:.6f} mm")


contact = Part.read(str(HERE / "Harwin_H2183_05_reverse_mount_proxy.step"))
box = contact.BoundBox
near(box.XMin, -1.125)
near(box.XMax, 1.125)
near(box.YMin, -1.125)
near(box.YMax, 1.125)
near(box.ZMin, -11.45)
near(box.ZMax, 0.40)

assembly = Part.read(str(HERE / "banana_power_contact_v0.3.step"))
box = assembly.BoundBox
near(box.XMin, 0.0)
near(box.XMax, 46.0)
near(box.YMin, 0.0)
near(box.YMax, 7.5)
near(box.ZMin, -11.45)
near(box.ZMax, 0.65)

print("PASS: STEP bbox board=46x7.5x1.6, pin tip Z=-11.45, tail Z=+0.40")
