# Banana contact v0.3 bare-PCB quote package

Status: **OWNER A5 CONDITIONAL ENGINEERING-SAMPLE RELEASE / FREE WEB PREVIEW REQUIRED / DO NOT POWER**.

- Upload only `Banana_Contact_v0_3_BARE_PCB_QUOTE.zip` to the PCB Gerber field.
- Board: 46 x 7.5 x 1.6 mm, 2 layers, 2 oz copper on both layers, green mask and white silkscreen.
- Surface finish: free HAL SnPb / leaded HASL. Do not select ENIG or paid lead-free HASL.
- Quantity: 5 bare PCBs. Do not order PCB assembly for this board.
- Do not select paid DFM, production-file review, stencil, X-ray, manual engineering confirmation, expedited service, gold fingers, edge plating, castellated holes, impedance control, via filling, or any other paid add-on.
- The ZIP deliberately contains no paste layer, BOM or CPL because F1, BT1, BT2 and the AWG16 wires are hand-installed after return.
- Expected drill set: two 1.80 mm plated wire holes and two 1.85 mm plated H2183-05 holes; zero NPTH holes.
- This package is released only for a small engineering fit sample after the owner's 2026-09-04 instruction to order if the free checks show no problem. It is not a final-production or power-up release.
- First return inspection is unpowered: verify 46 x 7.5 x 1.6 mm, 33.8 mm contact pitch, free insertion, polarity and clearance. Never connect the full 15-servo robot during first contact testing.
