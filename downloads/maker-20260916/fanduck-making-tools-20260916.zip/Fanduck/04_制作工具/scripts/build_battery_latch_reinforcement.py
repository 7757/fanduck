#!/usr/bin/env python3
"""Locally reinforce the power-support latch grooves for one nylon trial.

The delivered millimetre STL is the base. The upper groove valleys gain
0.30 mm, tapering smoothly to zero toward the hook. All other geometry,
including the flat back and groove crest envelope, is retained.
Pollen geometry derivative: CC BY-SA-NC, noncommercial research only.
"""
import hashlib
import json
import math
import struct
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

from prepare_tire_orientation_trial import read_mesh, check_mesh, cross, sub
from build_tire_fit_revision import profile_is_simple

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "work/3d-print-engineering/source-baselines/电源电池支架__原始毫米基线.stl"
BASE_HASH = "376a80349f7bab4861e3df405a1dea3c9e678e08892c38e247bf004867a5b3d8"
OUT = ROOT / "work/3d-print-engineering/battery-latch-v1"
TARGET = ROOT / "manufacturing/3D打印文件_中文零件名_颜色材质已分类_v3/08_尼龙PA12_深灰色或黑色/电源电池背板__卡扣根部加强v1__第01件_共01件.stl"
SOURCE_COMMIT = "d424a0c899f6b33cbd3daeb279913134349c0b63"
DRAFT = math.tan(math.pi/180)


def smoothstep(t):
    t = min(1.0,max(0.0,t))
    return t*t*(3-2*t)


def reinforcement(z):
    # z increases toward the main backplate. Preserve the distal grooves.
    return 0.30*smoothstep((z+19.1)/4.0)*smoothstep((-12.3-z)/0.5)


def transform(p):
    x,y,z = p
    if abs(x)>=5.3 or z<=-19.1 or z>=-12.3 or y<=25.000005 or y>=26.999995:
        return p
    lateral = 1-smoothstep((abs(x)-5.05)/0.25)
    h = y-25.0
    # C1 through h=0 and h=1, with monotone y mapping (dy'/dy >=0.7).
    # On the visible groove surface h=1..2 this flattens the groove depth.
    profile = h*h*(4-3*h) if h<1 else 2-h
    delta = reinforcement(z)*lateral*profile
    # Keep each original drafted side plane, instead of folding its old,
    # extremely thin triangles when the groove boundary changes.
    if abs(abs(x)-(5+DRAFT*(y-25)))<2e-6:
        x += math.copysign(DRAFT*delta,x)
    return (x,y+delta,z)


def orient(a,b,c):
    return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])


def rebuild_side_faces(faces):
    """Triangulate the revised simple side outlines, keeping all boundary nodes.

    Each of the two original side faces is a single 477-vertex polygon with
    475 triangles. The original concave-polygon triangulation is unsuitable
    after changing valley depths. Ear clipping changes only the tessellation
    of these two planes; it does not approximate the surrounding part.
    """
    removed=set();added=[]
    for sign in (-1,1):
        indices=[i for i,f in enumerate(faces) if all(
            abs(p[0]-sign*(5+DRAFT*(p[1]-25)))<2e-6 for p in f)]
        assert len(indices)==475
        edges=Counter(tuple(sorted((p,q))) for i in indices
                      for p,q in zip(faces[i],faces[i][1:]+faces[i][:1]))
        following={p:q for i in indices for p,q in zip(faces[i],faces[i][1:]+faces[i][:1])
                   if edges[tuple(sorted((p,q)))]==1}
        assert len(following)==477 and len(set(following.values()))==477
        p=start=next(iter(following));poly=[]
        while True:
            poly.append(transform(p));p=following[p]
            if p==start:break
            assert len(poly)<len(following)
        assert len(poly)==477
        projected=[p[1:] for p in poly]
        profile_is_simple(projected)
        area=sum(p[0]*q[1]-q[0]*p[1] for p,q in
                 zip(projected,projected[1:]+projected[:1]))/2
        direction=1 if area>0 else -1
        assert direction==sign
        remaining=list(range(len(poly)));side=[]
        while len(remaining)>3:
            for k,i in enumerate(remaining):
                prev,nex=remaining[k-1],remaining[(k+1)%len(remaining)]
                a,b,c=projected[prev],projected[i],projected[nex]
                if direction*orient(a,b,c)<=1e-10:continue
                if any(min(direction*orient(a,b,projected[j]),
                           direction*orient(b,c,projected[j]),
                           direction*orient(c,a,projected[j]))>=-1e-10
                       for j in remaining if j not in (prev,i,nex)):continue
                side.append((poly[prev],poly[i],poly[nex]));remaining.pop(k)
                break
            else:
                raise AssertionError('Side polygon cannot be triangulated safely')
        side.append(tuple(poly[i] for i in remaining))
        for a,b,c in side:
            assert cross(sub(b,a),sub(c,a))[0]*sign>1e-10
        removed.update(indices);added.extend(side)
    return removed,added


def binary_stl(faces):
    out=bytearray(b"Pollen CC BY-SA-NC derivative; latch root +0.30 mm graded; mm; v1".ljust(80,b" "))
    out.extend(struct.pack('<I',len(faces)))
    for a,b,c in faces:
        normal=cross(sub(b,a),sub(c,a));length=math.sqrt(sum(v*v for v in normal))
        assert length>1e-9
        out.extend(struct.pack('<12fH',*(v/length for v in normal),*a,*b,*c,0))
    return bytes(out)


def bounds(faces):
    pts=[p for f in faces for p in f]
    return [(min(p[i] for p in pts),max(p[i] for p in pts)) for i in range(3)]


def section(faces,x=0.000123):
    lines=[]
    for f in faces:
        pts=[]
        for a,b in zip(f,f[1:]+f[:1]):
            if min(a[0],b[0])<x<max(a[0],b[0]):
                t=(x-a[0])/(b[0]-a[0])
                pts.append((a[1]+t*(b[1]-a[1]),a[2]+t*(b[2]-a[2])))
        if len(pts)==2:lines.append(pts)
    return lines


def thickness_at(lines,z):
    ys=[]
    for a,b in lines:
        if min(a[1],b[1])<z<max(a[1],b[1]):
            ys.append(a[0]+(z-a[1])*(b[0]-a[0])/(b[1]-a[1]))
    ys=sorted(set(round(v,7) for v in ys))
    assert len(ys)==2,(z,ys)
    return ys[-1]-ys[0]


def figure(old_lines,new_lines,measures):
    def screen(p):
        y,z=p
        return (155+(y-25)*110,154+(-12.2-z)*40)
    parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1120" height="710" viewBox="0 0 1120 710">',
        '<title>电池背板卡扣根部加强v1</title>',
        '<desc>沿卡扣中央截取实际STL剖面，根部两道凹槽最薄处从约1毫米增加到1.3毫米，向卡钩端渐变回原厚度。外形和安装孔位不变。尼龙单件试样，尚未实物验证。</desc>',
        '<rect width="1120" height="710" fill="#faf9f6"/>',
        '<g font-family="PingFang SC, sans-serif" fill="#1d2939">',
        '<text x="38" y="48" font-size="27" font-weight="600">电池背板：卡扣根部两道薄槽局部增厚</text>',
        '<text x="38" y="79" font-size="17" fill="#667085">实际 STL 中央剖面对比 · 单位 mm · 尼龙开发试样，未验证装配力和寿命</text>',
        '<text x="114" y="124" font-size="18">靠主体</text>',
        '<text x="106" y="591" font-size="18">靠按压块 / 卡钩</text>']
    for lines,color,width,dash in [(old_lines,'#98a2b3',2.5,'5 4'),(new_lines,'#dc6b23',2.0,'')]:
        for a,b in lines:
            if max(a[1],b[1])>-12.3 or min(a[1],b[1])<-22.2:continue
            if max(a[0],b[0])>27.00001:continue
            aa,bb=screen(a),screen(b)
            parts.append(f'<line x1="{aa[0]:.3f}" y1="{aa[1]:.3f}" x2="{bb[0]:.3f}" y2="{bb[1]:.3f}" stroke="{color}" stroke-width="{width}" stroke-dasharray="{dash}"/>')
    for row in measures:
        if row['groove_index_from_root'] in (1,2,6):
            yy=screen((25,row['section_z_mm']))[1]
            xend=155+110*row['after_thickness_mm']
            parts.append(f'<line x1="155" y1="{yy:.2f}" x2="{xend:.2f}" y2="{yy:.2f}" stroke="#667085" stroke-width="1.1"/>')
            parts.append(f'<text x="{xend+13:.2f}" y="{yy+5:.2f}" font-size="15">{row["after_thickness_mm"]:.2f}</text>')
    parts += [
        '<text x="514" y="163" font-size="22" font-weight="600">根部两道槽底：约 1.0 → 1.3 mm</text>',
        '<text x="514" y="196" font-size="18">增加约 0.30 mm，并平缓槽底轮廓</text>',
        '<text x="514" y="263" font-size="22" font-weight="600">往按压端平滑减小加强量</text>',
        '<text x="514" y="296" font-size="18">末端两道槽保留约 1.0 mm 的原厚度</text>',
        '<text x="514" y="329" font-size="18">保持弹性区原长度，不填实全部凹槽</text>',
        '<rect x="496" y="367" width="582" height="125" rx="12" fill="#eaf0f7"/>',
        '<text x="516" y="400" font-size="20" font-weight="600">保留外形、安装孔、滑轨、卡钩及触点位置</text>',
        '<text x="516" y="432" font-size="18">外廓仍为 54.5 × 17.0 × 83.4898 mm</text>',
        '<text x="516" y="464" font-size="17">新增材料位于凹槽中，不超出原有槽顶包络</text>',
        '<line x1="513" y1="535" x2="555" y2="535" stroke="#98a2b3" stroke-width="3" stroke-dasharray="5 4"/>',
        '<text x="568" y="541" font-size="17">灰色虚线：原版</text>',
        '<line x1="764" y1="535" x2="806" y2="535" stroke="#dc6b23" stroke-width="3"/>',
        '<text x="819" y="541" font-size="17">橙色实线：加强版</text>',
        '<text x="514" y="586" font-size="17">先做 1 件尼龙试样，不接电检查按压回弹和电池锁止。</text>',
        '<text x="38" y="657" font-size="14" fill="#667085">Pollen microduck_rl develop @ d424a0c · 3D 模型 CC BY-SA-NC · 本项目局部衍生，2026-09-05</text>',
        '<text x="38" y="685" font-size="14" fill="#667085">数字几何检查不等于材料、按压力或疲劳寿命通过。加强后仍需保留完整的电池释放行程。</text>',
        '</g></svg>']
    svg='\n'.join(parts)+'\n';ET.fromstring(svg)
    (OUT/'卡扣根部加强剖面对比.svg').write_text(svg)


def main():
    source=BASE.read_bytes();assert hashlib.sha256(source).hexdigest()==BASE_HASH
    old_faces=read_mesh(source);before_check=check_mesh(old_faces)
    removed,side_faces=rebuild_side_faces(old_faces)
    retained=[f for i,f in enumerate(old_faces) if i not in removed]
    new_faces=[tuple(transform(p) for p in f) for f in retained]+side_faces
    data=binary_stl(new_faces);actual=read_mesh(data);after_check=check_mesh(actual)
    assert bounds(actual)==bounds(old_faces)
    changes=[];affected_faces=[];unchanged_count=0;lowest_normal_dot=1.0
    output_points={p for f in actual for p in f}
    source_points=sorted({p for f in old_faces for p in f})
    moved_points=set()
    for p in source_points:
        q=struct.unpack('<3f',struct.pack('<3f',*transform(p)))
        assert q in output_points and p[2]==q[2]
        if p!=q:
            assert -19.1<p[2]<-12.3 and abs(p[0])<5.3 and 25<p[1]<27
            assert -1e-8<q[1]-p[1]<0.30001 and q[1]<27.00001
            assert abs(q[0]-p[0])<0.00524
            changes.append({'before':p,'after':q,'delta_y_mm':q[1]-p[1],
                            'delta_x_mm':q[0]-p[0]})
            moved_points.add(q)
        else:
            unchanged_count+=1
    assert len(output_points)==len(source_points)
    unchanged_face_count=0
    for before,after in zip(retained,actual):
        n0=cross(sub(before[1],before[0]),sub(before[2],before[0]));n1=cross(sub(after[1],after[0]),sub(after[2],after[0]))
        dot=sum(a*b for a,b in zip(n0,n1))/math.sqrt(sum(a*a for a in n0)*sum(a*a for a in n1))
        lowest_normal_dot=min(lowest_normal_dot,dot);assert dot>0
        if before==after:unchanged_face_count+=1
    affected_faces=[f for f in actual if any(p in moved_points for p in f)]
    assert changes
    volume_delta=after_check['signed_volume_mm3']-before_check['signed_volume_mm3'];assert volume_delta>0
    old_lines,new_lines=section(old_faces),section(actual)
    measures=[]
    for index,z0 in enumerate([-13.4,-14.9,-16.4,-17.9,-19.4,-20.9],1):
        candidates=[z0-0.74+i*.0005 for i in range(2961)]
        old_min_z=min(candidates,key=lambda z:thickness_at(old_lines,z))
        new_min_z=min(candidates,key=lambda z:thickness_at(new_lines,z))
        old_t=thickness_at(old_lines,old_min_z);new_t=thickness_at(new_lines,new_min_z)
        measures.append({'groove_index_from_root':index,'section_z_mm':new_min_z,'original_min_z_mm':old_min_z,
                         'before_thickness_mm':old_t,'after_thickness_mm':new_t,'increase_mm':new_t-old_t})
    assert all(abs(row['after_thickness_mm']-1.3)<.008 for row in measures[:2])
    assert all(abs(row['increase_mm'])<1e-7 for row in measures[-2:])
    # The complete affected surface patch stays behind the board back plane.
    # Official assembly transform: trunk=(4-y, x, z-17.5215) millimetres.
    patch_trunk=[tuple((4-p[1],p[0],p[2]-17.5215) for p in f) for f in affected_faces]
    patch_bounds=bounds(patch_trunk)
    board_back_x=-20.8
    assert patch_bounds[0][1]<board_back_x
    report={'date':'2026-09-05','version':'v1','units':'mm','status':'DEVELOPMENT NYLON TRIAL; NOT PHYSICALLY VERIFIED',
        'source_commit':SOURCE_COMMIT,'source_file':str(BASE.relative_to(ROOT)),'source_sha256':BASE_HASH,
        'upstream_geometry_license':'CC BY-SA-NC','output_file':TARGET.name,'output_sha256':hashlib.sha256(data).hexdigest(),
        'source_mesh':before_check,'output_mesh':after_check,'bounds_mm':bounds(actual),
        'bounds_size_mm':[hi-lo for lo,hi in bounds(actual)],'geometry_actually_modified':True,
        'max_vertex_y_increase_mm':max(c['delta_y_mm'] for c in changes),'modified_unique_vertices':len(changes),
        'unchanged_unique_vertices':unchanged_count,'changed_surface_face_count':len(affected_faces),
        'z_coordinates_bitwise_unchanged':True,'all_other_vertices_bitwise_unchanged':True,
        'max_side_draft_x_adjustment_mm':max(abs(c['delta_x_mm']) for c in changes),
        'side_draft_plane_preserved_within_mm':0.000002,
        'side_triangles_rebuilt':len(side_faces),'retained_faces_bitwise_unchanged':unchanged_face_count,
        'minimum_retained_face_normal_direction_dot':lowest_normal_dot,'solid_volume_increase_mm3':volume_delta,
        'groove_thickness_measurements':measures,'affected_patch_bounds_in_trunk_mm':patch_bounds,
        'board_back_plane_x_mm':board_back_x,'patch_to_board_plane_gap_lower_bound_mm':board_back_x-patch_bounds[0][1],
        'physical_release_travel_verified':False,'assembly_force_verified':False,'fatigue_life_verified':False,
        'nylon_selected_by_owner':True,'actual_nylon_grade_verified':False,
        'limitations':['Nominal geometry only. Real battery shape and print tolerance need an unpowered dry fit.',
                       'Added thickness may increase pressing force. This is not a certified fatigue or retention improvement.',
                       'The existing global 0.082 mm board clearance elsewhere is not enlarged or physically validated.',
                       'Current and locked upstream power_support have identical triangle geometry per the 2026-09-05 source audit. No unidentified user modification is claimed to be merged.']}
    OUT.mkdir(parents=True,exist_ok=True);TARGET.parent.mkdir(parents=True,exist_ok=True);TARGET.write_bytes(data)
    (OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (OUT/'changed-vertices.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
    figure(old_lines,new_lines,measures)
    assert hashlib.sha256(BASE.read_bytes()).hexdigest()==BASE_HASH
    print(json.dumps({'file':str(TARGET),'mesh':after_check,'thickness':measures,
                      'max_change_mm':report['max_vertex_y_increase_mm'],'volume_added_mm3':volume_delta,
                      'patch_board_gap_lower_bound_mm':report['patch_to_board_plane_gap_lower_bound_mm']},ensure_ascii=False,indent=2))


if __name__=='__main__':
    main()
