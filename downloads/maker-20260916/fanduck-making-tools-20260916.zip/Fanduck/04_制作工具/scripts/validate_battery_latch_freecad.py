"""Independently inspect the exported latch STL with FreeCAD's mesh kernel.

Run from the project root with:
  /Applications/FreeCAD.app/Contents/Resources/bin/freecadcmd scripts/validate_battery_latch_freecad.py
"""
import hashlib
import json
from pathlib import Path

import FreeCAD
import Mesh

root = Path(__file__).resolve().parents[1]
folder = root / 'work/3d-print-engineering/battery-latch-v1'
record = json.loads((folder / 'validation.json').read_text())
path = root / 'manufacturing/3D打印文件_中文零件名_颜色材质已分类_v3/08_尼龙PA12_深灰色或黑色/电源电池背板__卡扣根部加强v1__第01件_共01件.stl'
digest = hashlib.sha256(path.read_bytes()).hexdigest()
assert digest == record['output_sha256']
mesh = Mesh.Mesh(str(path))
checks = {
    'is_solid': mesh.isSolid(),
    'has_non_manifolds': mesh.hasNonManifolds(),
    'has_nonuniform_oriented_facets': mesh.hasNonUniformOrientedFacets(),
    'self_intersection_pairs': len(mesh.getSelfIntersections()),
    'facets': mesh.CountFacets,
    'vertices': mesh.CountPoints,
    'volume_mm3': mesh.Volume,
}
print(json.dumps(checks), flush=True)
assert checks['is_solid'], 'not solid'
assert not checks['has_non_manifolds'], 'nonmanifold geometry'
assert not checks['has_nonuniform_oriented_facets'], 'inconsistent orientation'
assert checks['self_intersection_pairs'] == 0, 'self intersections'
assert checks['facets'] == record['output_mesh']['triangles'], 'face count mismatch'
# FreeCAD Mesh reports this volume through single-precision mesh arithmetic.
# Compare at 10 ppm, rather than imposing double-precision absolute accuracy.
checks['volume_relative_difference'] = abs(checks['volume_mm3'] - record['output_mesh']['signed_volume_mm3']) / record['output_mesh']['signed_volume_mm3']
assert checks['volume_relative_difference'] < 0.00001, 'volume mismatch exceeds 10 ppm'
report = {
    'tool': 'FreeCAD Mesh kernel',
    'version': list(FreeCAD.Version()),
    'file': path.name,
    'sha256': digest,
    'checks': checks,
    'physical_fit_or_strength_validated': False,
}
(folder / 'freecad-validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
