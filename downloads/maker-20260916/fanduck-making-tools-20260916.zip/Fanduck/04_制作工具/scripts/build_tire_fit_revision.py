#!/usr/bin/env python3
"""Build a local tire fit trial, preserving the tread and rigid wheel core.

Pollen geometry: CC BY-SA-NC. This is a noncommercial project derivative,
not Pollen's manufacturing design. No historical package is overwritten.
"""
import hashlib
import json
import math
import struct
from pathlib import Path
import xml.etree.ElementTree as ET

from prepare_tire_orientation_trial import read_mesh, check_mesh, cross, sub

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "sources/official/microduck_rl/src/mjlab_microduck/robot/microduck/assets"
OUT = ROOT / "work/3d-print-engineering/tire-fit-v2"
TARGET_DIR = ROOT / "manufacturing/3D打印文件_中文零件名_颜色材质已分类_v3/10_滚轮组件_柔性TPU_黑色"
TARGET = TARGET_DIR / "轮胎__入口17.2_口沿17.6_内槽20.8__修正版v2__第01件_共04件.stl"
LOCKED_HASHES = {
    "tire.stl": "9f680806474bcfaa5b0a1db5b008578ccbedb33b60a39221c494cbff409033c9",
    "rim.stl": "c2a84cd05ed8ce87bbdd64950bca415ba5945641385f5ec7cdbb161aa37281a4",
}
# Axial position relative to wheel midplane, then radius; dimensions in mm.
OLD_INNER = [(-3.8,8.1),(-2.5,8.1),(-2.5,10.1),(-1.3,10.1),(-1.3,8.1),
             (1.3,8.1),(1.3,10.1),(2.5,10.1),(2.5,8.1),(3.8,8.1)]
NEW_INNER = [(-3.8,8.8),(-3.4,8.6),(-2.8,8.6),(-2.8,10.4),(-1.0,10.4),
             (-1.0,8.6),(-0.4,8.1),(0.4,8.1),(1.0,8.6),(1.0,10.4),
             (2.8,10.4),(2.8,8.6),(3.4,8.6),(3.8,8.8)]
RIM_INNER = [(-3.8,6.1),(-1,6.1),(-1,4.9),(1,4.9),(1,6.1),(3.8,6.1)]


def mesh_bytes(faces):
    data = bytearray(b"Pollen CC BY-SA-NC derivative; tire fit v2; mm; single trial".ljust(80,b" "))
    data.extend(struct.pack("<I",len(faces)))
    for a,b,c in faces:
        n = cross(sub(b,a),sub(c,a))
        length = math.sqrt(sum(v*v for v in n))
        data.extend(struct.pack("<12fH",*(v/length for v in n),*a,*b,*c,0))
    return bytes(data)


def profile_is_simple(poly):
    def orient(a,b,c):
        return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
    def on_segment(a,b,c):
        return (abs(orient(a,b,c)) < 1e-9 and
                min(a[0],b[0])-1e-9 <= c[0] <= max(a[0],b[0])+1e-9 and
                min(a[1],b[1])-1e-9 <= c[1] <= max(a[1],b[1])+1e-9)
    n = len(poly)
    for i in range(n):
        a,b = poly[i],poly[(i+1)%n]
        assert a != b
        for j in range(i+1,n):
            if j in {(i+1)%n,(i-1)%n}:
                continue
            c,d = poly[j],poly[(j+1)%n]
            strict = orient(a,b,c)*orient(a,b,d) < 0 and orient(c,d,a)*orient(c,d,b) < 0
            assert not (strict or on_segment(a,b,c) or on_segment(a,b,d)
                        or on_segment(c,d,a) or on_segment(c,d,b)), (i,j)


def make_figure(outer):
    def points(profile):
        return " ".join(f"{315+60*a:.2f},{505-24*r:.2f}" for a,r in profile)
    before_outer = [(-3.8,8.1)] + outer[1:-1] + [(3.8,8.1)]
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="710" viewBox="0 0 1200 710">',
             '<title>轮胎v2实际尺寸修改</title>',
             '<desc>上半轴向剖面。扩大入口和两道内槽；中部保留16.2毫米直径、0.8毫米宽的贴合圈。外径30毫米及总宽7.6毫米保留。待实物试装。</desc>',
             '<rect width="1200" height="710" fill="#faf9f6"/>',
             '<g font-family="PingFang SC, sans-serif" fill="#1d2939">',
             '<text x="38" y="48" font-size="28" font-weight="600">轮胎 v2：已修改入口、内槽和中间贴合段</text>',
             '<text x="38" y="79" font-size="17" fill="#667085">过轮轴切开的上半剖面 · 标注均为毫米 · 单只开发试样，尚未打印验证</text>',
             f'<polygon points="{points(before_outer+list(reversed(OLD_INNER))[1:-1])}" fill="#fdd9c7"/>',
             f'<polygon points="{points(outer+list(reversed(NEW_INNER))[1:-1])}" fill="#dbe8f7" stroke="#2765a4" stroke-width="1.7"/>',
             f'<polyline points="{points(OLD_INNER)}" fill="none" stroke="#b84b18" stroke-dasharray="5 4" stroke-width="1.5"/>',
             f'<polygon points="{points(OLD_INNER+list(reversed(RIM_INNER)))}" fill="#f7bb3c" stroke="#aa7000" stroke-width="1.4"/>',
             '<line x1="57" y1="505" x2="573" y2="505" stroke="#98a2b3" stroke-dasharray="7 5"/>',
             '<text x="270" y="535" font-size="16">轮轴中心线</text>',
             '<text x="58" y="119" font-size="15" fill="#2765a4">蓝色：改后的软胎；黄色：未改的硬轮芯</text>',
             '<text x="638" y="144" font-size="20" font-weight="600">入口主要通过段：16.2 → 17.2</text>',
             '<text x="638" y="176" font-size="18">口沿斜面最大开到 17.6</text>',
             '<text x="638" y="237" font-size="20" font-weight="600">两道内槽槽底：20.2 → 20.8</text>',
             '<text x="638" y="269" font-size="18">每道槽宽：1.2 → 1.8，槽中心位置保留</text>',
             '<text x="638" y="330" font-size="20" font-weight="600">中间贴合圈：直径仍为 16.2</text>',
             '<text x="638" y="362" font-size="18">等径段宽度 2.6 → 0.8，两侧加斜面</text>',
             '<text x="638" y="394" font-size="17" fill="#667085">此处仍需弹性撑开；不保证装配力或锁止力</text>',
             '<rect x="622" y="428" width="536" height="129" rx="12" fill="#fff1d6"/>',
             '<text x="644" y="459" font-size="20" font-weight="600">外径 30、总宽 7.6；轮芯和轴承孔不改</text>',
             '<text x="644" y="490" font-size="17">先打印这版 1 只，常温试装、检查防滑与脱圈。</text>',
             '<text x="644" y="521" font-size="17">通过后其余 3 只用同一版本和打印参数。</text>',
             '<rect x="57" y="570" width="535" height="51" rx="10" fill="#fdd9c7"/>',
             '<text x="77" y="602" font-size="17">橙红虚线：原内侧轮廓；唇口外沿也作局部调整</text>',
             '<text x="38" y="663" font-size="14" fill="#667085">Pollen microduck_rl develop @ d424a0c · 原模型 CC BY-SA-NC · 本项目衍生 v2，2026-09-05</text>',
             '<text x="38" y="689" font-size="14" fill="#667085">图示为名义几何；实际牌号、制造公差范围、装配力和滚动表现待验证。</text>',
             '</g></svg>']
    svg = "\n".join(parts)+"\n"
    ET.fromstring(svg)
    (OUT/"轮胎v2尺寸修改剖面.svg").write_text(svg)


def main():
    source = {}
    for name,digest in LOCKED_HASHES.items():
        source[name] = (ASSETS/name).read_bytes()
        assert hashlib.sha256(source[name]).hexdigest() == digest
    source_faces = [tuple(tuple(v*1000 for v in p) for p in f) for f in read_mesh(source["tire.stl"])]
    pts = {p for f in source_faces for p in f}
    bounds = [(min(p[i] for p in pts),max(p[i] for p in pts)) for i in range(3)]
    cx,cy,cz = [(a+b)/2 for a,b in bounds]
    halfwidth = (bounds[0][1]-bounds[0][0])/2
    def key(p):
        return (round(p[0]-cx,3),round(math.hypot(p[1]-cy,p[2]-cz),3))
    inner_keys = set(OLD_INNER[1:-1])
    def transform(p):
        x,y,z = p[1]-cy,p[2]-cz,p[0]-bounds[0][0]
        if key(p) in {OLD_INNER[0],OLD_INNER[-1]}:
            ratio = 8.8/math.hypot(x,y)
            x,y = x*ratio,y*ratio
        return (x,y,z)
    # All original tread faces retained, except moving the two mouth-edge rings.
    outer_sources = [f for f in source_faces if not any(key(p) in inner_keys for p in f)]
    outer_faces = [tuple(transform(p) for p in f) for f in outer_sources]
    assert len(outer_faces) == 5760
    end_rings = []
    for end in (OLD_INNER[0],OLD_INNER[-1]):
        ps = [transform(p) for p in pts if key(p) == end]
        # Start just after the negative X direction consistently despite tiny floats.
        ps.sort(key=lambda p: round(math.atan2(p[1],p[0]),5))
        assert len(ps) == 72
        end_rings.append(ps)
    theta = [math.atan2(p[1],p[0]) for p in end_rings[0]]
    assert max(abs(math.atan2(p[1],p[0])-t) for p,t in zip(end_rings[1],theta)) < 0.00001
    rings = [end_rings[0]]
    for a,r in NEW_INNER[1:-1]:
        rings.append([(r*math.cos(t),r*math.sin(t),a+halfwidth) for t in theta])
    rings.append(end_rings[1])
    inner_faces = []
    for lower,upper in zip(rings,rings[1:]):
        for j in range(72):
            k = (j+1)%72
            inner_faces.extend([(lower[j],upper[k],lower[k]),(lower[j],upper[j],upper[k])])
    encoded = mesh_bytes(outer_faces+inner_faces)
    output_faces = read_mesh(encoded)
    check = check_mesh(output_faces)
    source_check = check_mesh(source_faces)
    volume_change = check["signed_volume_mm3"]-source_check["signed_volume_mm3"]
    assert volume_change < 0
    points = [p for f in output_faces for p in f]
    out_bounds = [(min(p[i] for p in points),max(p[i] for p in points)) for i in range(3)]
    assert out_bounds[2][0] == 0
    assert all(abs((hi-lo)-expected) < 0.00001 for (lo,hi),expected in zip(out_bounds,(30,30,7.6)))
    # Independently read the emitted vertices and check every new profile station.
    for ring,(a,r) in zip(rings,NEW_INNER):
        assert all(abs(math.hypot(x,y)-r)<0.00001 and abs(z-halfwidth-a)<0.00001 for x,y,z in ring)
    output_set = set(points)
    for ring in rings:
        for p in ring:
            assert struct.unpack('<3f',struct.pack('<3f',*p)) in output_set
    unchanged_vertices = [p for p in pts if key(p) not in inner_keys|{OLD_INNER[0],OLD_INNER[-1]}]
    max_tread_error = 0.0
    for p in unchanged_vertices:
        target = (p[1]-cy,p[2]-cz,p[0]-bounds[0][0])
        actual = struct.unpack('<3f',struct.pack('<3f',*target))
        assert actual in output_set
        max_tread_error = max(max_tread_error,max(abs(u-v) for u,v in zip(target,actual)))
    assert max_tread_error < 0.00001
    outer_profile = sorted({key(p) for p in pts if key(p) not in inner_keys})
    outer_profile[0],outer_profile[-1] = NEW_INNER[0],NEW_INNER[-1]
    profile_is_simple(outer_profile+list(reversed(NEW_INNER))[1:-1])
    # At all break points and intervals, the revised cavity still clears the
    # original nominal core (except intentional equality at its central land).
    def radii_at(profile,a):
        vals=[]
        for (x0,r0),(x1,r1) in zip(profile,profile[1:]):
            if min(x0,x1)-1e-8 <= a <= max(x0,x1)+1e-8:
                if abs(x1-x0)<1e-8:
                    vals += [r0,r1]
                else:
                    vals.append(r0+(r1-r0)*(a-x0)/(x1-x0))
        return vals
    breaks=sorted({a for a,r in OLD_INNER+NEW_INNER})
    sample_axial=breaks+[(a+b)/2 for a,b in zip(breaks,breaks[1:])]
    for a in sample_axial:
        assert min(radii_at(NEW_INNER,a))+1e-8 >= max(radii_at(OLD_INNER,a)),a
    OUT.mkdir(parents=True,exist_ok=True)
    TARGET_DIR.mkdir(parents=True,exist_ok=True)
    TARGET.write_bytes(encoded)
    for copy_index in range(2, 5):
        (TARGET_DIR / f"轮胎__入口17.2_口沿17.6_内槽20.8__修正版v2__第{copy_index:02d}件_共04件.stl").write_bytes(encoded)
    make_figure(outer_profile)
    validation = {
        "date":"2026-09-05","version":"v2","status":"DEVELOPMENT TRIAL - NOT PHYSICALLY VERIFIED",
        "source_commit":"d424a0c899f6b33cbd3daeb279913134349c0b63",
        "upstream_geometry_license":"CC BY-SA-NC","source_sha256":LOCKED_HASHES,
        "file":TARGET.name,"output_sha256":hashlib.sha256(encoded).hexdigest(),
        "units":"mm","axle_axis":"Z","geometry_resized":True,
        "physical_fit_verified":False,"slicing_verified":False,"material_grade_verified":False,
        "old_inner_axial_radius_mm":OLD_INNER,"new_inner_axial_radius_mm":NEW_INNER,
        "dimensions_mm":{
            "mouth_diameter":{"before":16.2,"after":17.6,"increase":1.4},
            "entry_passage_diameter":{"before":16.2,"after":17.2,"increase":1.0},
            "groove_floor_diameter":{"before":20.2,"after":20.8,"increase":0.6},
            "groove_axial_width":{"before":1.2,"after":1.8,"increase":0.6},
            "central_land_diameter":{"before":16.2,"after":16.2,"increase":0.0},
            "central_cylindrical_land_width":{"before":2.6,"after":0.8,"increase":-1.8},
            "groove_center_axial_positions":[-1.9,1.9],"outer_diameter":30.0,"total_width":7.6},
        "design_limitations":["Central 16.2 mm land still requires elastic deformation to pass a 20.2 mm flange.",
                              "Neither assembly-force improvement nor retention force has been measured.",
                              "Mouth-edge outer geometry is locally changed; remaining tread vertices are preserved.",
                              "Vendor +/-0.2 mm scope for internal dimensions, feature locations and TPU is unconfirmed."],
        "nominal_core_radial_intersection":False,"profile_simple":True,
        "unaltered_tread_vertex_count":len(unchanged_vertices),"max_tread_vertex_error_mm":max_tread_error,
        "output_bounds_mm":out_bounds,"source_mesh":source_check,"output_mesh":check,
        "solid_volume_change_mm3":volume_change,"solid_volume_change_percent":100*volume_change/source_check["signed_volume_mm3"],
        "diameter_tolerance_assuming_both_plus_minus_0p2_mm":{
            "groove_to_flange_diametral_clearance_range":[0.2,1.0],
            "central_land_to_core_diametral_clearance_range":[-0.4,0.4],
            "outer_throat_to_flange_nominal_radial_retention_overlap":1.5},
        "width_tolerance_assuming_both_plus_minus_0p2_mm":{
            "groove_minus_flange_width_range":[0.2,1.0],
            "note":"Width difference alone does not include groove/feature positional error."}}
    (OUT/'validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
    for name,digest in LOCKED_HASHES.items():
        assert hashlib.sha256((ASSETS/name).read_bytes()).hexdigest()==digest
    print(json.dumps({"file":str(TARGET),"validation":check,"volume_change_mm3":volume_change,
                      "volume_change_percent":validation['solid_volume_change_percent'],
                      "preserved_tread_vertices":len(unchanged_vertices)},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
