#!/usr/bin/env python3
"""Prepare one unchanged-size tire with its axle vertical; no fit revision.

Read the locked Pollen mesh, preserve its triangles, convert m to mm, and
apply an orientation-preserving rigid transform. Original packages stay intact.
The derivative geometry retains the upstream CC BY-SA-NC licence.
"""
import hashlib
import json
import math
import struct
from collections import defaultdict
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "sources/official/microduck_rl/src/mjlab_microduck/robot/microduck/assets/tire.stl"
OUT = ROOT / "manufacturing/tire-fit-trial-v1"
TARGET = OUT / "轮轴朝上_原尺寸轮胎_首件1只.stl"
SOURCE_HASH = "9f680806474bcfaa5b0a1db5b008578ccbedb33b60a39221c494cbff409033c9"


def read_mesh(data):
    count = struct.unpack_from("<I", data, 80)[0]
    assert len(data) == 84 + 50 * count
    return [tuple(struct.unpack_from("<3f", data, 96 + 50*i + 12*j)
                  for j in range(3)) for i in range(count)]


def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def sub(a, b):
    return tuple(x-y for x, y in zip(a, b))


def check_mesh(faces):
    edges = defaultdict(list)
    volume = 0.0
    for i, (a, b, c) in enumerate(faces):
        assert math.sqrt(sum(v*v for v in cross(sub(b, a), sub(c, a)))) > 1e-9
        volume += sum(v*w for v, w in zip(a, cross(b, c))) / 6
        for p, q in ((a, b), (b, c), (c, a)):
            edges[tuple(sorted((p, q)))].append((i, p < q))
    assert all(len(v) == 2 and v[0][1] != v[1][1] for v in edges.values())
    neighbors = defaultdict(set)
    for pair in edges.values():
        a, b = pair[0][0], pair[1][0]
        neighbors[a].add(b)
        neighbors[b].add(a)
    seen, todo = set(), [0]
    while todo:
        i = todo.pop()
        if i not in seen:
            seen.add(i)
            todo.extend(neighbors[i] - seen)
    assert len(seen) == len(faces) and volume > 0
    return {"triangles": len(faces), "closed_consistently_wound": True,
            "connected_components": 1, "degenerate_faces": 0,
            "signed_volume_mm3": volume}


def main():
    original = SOURCE.read_bytes()
    assert hashlib.sha256(original).hexdigest() == SOURCE_HASH
    mm_faces = [tuple(tuple(v*1000 for v in p) for p in f) for f in read_mesh(original)]
    points = [p for f in mm_faces for p in f]
    bounds = [(min(p[i] for p in points), max(p[i] for p in points)) for i in range(3)]
    cy, cz = [(low+high)/2 for low, high in bounds[1:]]
    # (X,Y,Z) -> (Y,Z,X) is a proper rotation, followed by translation.
    def transform(p):
        return (p[1]-cy, p[2]-cz, p[0]-bounds[0][0])
    transformed = [tuple(transform(p) for p in f) for f in mm_faces]
    encoded = bytearray(b"Pollen tire CC BY-SA-NC; mm; axle Z; original size; single trial".ljust(80, b" "))
    encoded.extend(struct.pack("<I", len(transformed)))
    for a, b, c in transformed:
        n = cross(sub(b, a), sub(c, a))
        length = math.sqrt(sum(v*v for v in n))
        encoded.extend(struct.pack("<12fH", *(v/length for v in n), *a, *b, *c, 0))
    actual = read_mesh(encoded)
    original_check, output_check = check_mesh(mm_faces), check_mesh(actual)
    max_error = max(abs(u-v) for f, g in zip(transformed, actual)
                    for p, q in zip(f, g) for u, v in zip(p, q))
    assert max_error < 0.00001
    assert abs(original_check["signed_volume_mm3"] - output_check["signed_volume_mm3"]) < 0.001
    actual_points = [p for f in actual for p in f]
    out_bounds = [(min(p[i] for p in actual_points), max(p[i] for p in actual_points)) for i in range(3)]
    for (low, high), expected in zip(out_bounds, (30, 30, 7.6)):
        assert abs(high-low-expected) < 0.00001
    assert out_bounds[2][0] == 0
    d, tolerance = Decimal("20.2"), Decimal("0.2")
    examples = []
    for target in ("20.2", "20.4", "20.6", "20.8"):
        D = Decimal(target)
        examples.append({"groove_nominal_diameter_mm": float(D),
                         "flange_nominal_diameter_mm": float(d),
                         "minimum_diametral_clearance_mm": float((D-tolerance)-(d+tolerance)),
                         "maximum_diametral_clearance_mm": float((D+tolerance)-(d-tolerance))})
    evidence = {
        "date": "2026-09-05", "source_commit": "d424a0c899f6b33cbd3daeb279913134349c0b63",
        "source": str(SOURCE.relative_to(ROOT)), "source_sha256": SOURCE_HASH,
        "output": TARGET.name, "output_sha256": hashlib.sha256(encoded).hexdigest(),
        "units": "mm", "change": "unit conversion, rigid rotation and translation only",
        "geometry_resized": False, "groove_relief_exported": False,
        "physical_fit_verified": False, "slicing_verified": False,
        "output_bounds_mm": out_bounds, "max_roundtrip_vertex_error_mm": max_error,
        "source_geometry": original_check, "output_geometry": output_check,
        "tolerance_assumption": "Both FINISHED DIAMETERS independently +/-0.2 mm; vendor scope is unconfirmed. Negative clearance means interference. Examples are calculations, not approved geometry revisions.",
        "diametral_clearance_examples": examples,
        "unchanged_features_mm": {"tire_entry_diameter": 16.2, "tire_groove_diameter": 20.2,
                                   "tire_groove_width": 1.2, "tire_outer_diameter": 30, "total_width": 7.6}}
    OUT.mkdir(parents=True, exist_ok=True)
    TARGET.write_bytes(encoded)
    (OUT / "validation.json").write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n")
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == SOURCE_HASH
    print(json.dumps({"file": str(TARGET), "check": output_check, "tolerance_examples": examples}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
