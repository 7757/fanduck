# 只保留制作物料所需工具

本目录不是 App、网站或机器人运行软件。它只包含当前打印修正版的生成与几何检查脚本，以及必要输入和检查记录。

| 文件 | 用途 |
| --- | --- |
| `scripts/build_battery_latch_reinforcement.py` | 生成电池背板卡扣根部加强 v1 |
| `scripts/build_tire_fit_revision.py` | 生成轮胎配合修正版 v2 |
| `scripts/prepare_tire_orientation_trial.py` | 上述工具导入的网格读取和检查函数；不要单独执行其旧首样输出入口 |
| `scripts/validate_battery_latch_freecad.py` | 对生成后的背板网格作独立 FreeCAD 检查 |
| `work/3d-print-engineering/` | 修正基线、剖面图、数字检查记录；不是另一套待打印件 |
| `sources/official/microduck_rl/.../assets/` | 仅保留工具需要的原始轮胎与轮毂模型，不含训练系统 |

两个生成脚本使用 Python 标准库；独立检查脚本需 FreeCAD 的 Python 模块。脚本依据自己的位置定位根目录，输出到**本目录内部**的 `manufacturing/`，不覆盖本包 `02_打印件/` 或原项目。未在本次重新执行生成，也不声称新增实物验证。

完整生产打印请直接使用 `02_打印件/中文材料分类_v3/`，不要把输入基线或旧首样输出当成当前打印文件。源文件保留原注释和非商业模型署名。

面板旧转接试验、旧包拼装脚本及缺少输入的历史工具没有纳入。电路板编辑使用 KiCad；其外部库授权边界见来源目录。
