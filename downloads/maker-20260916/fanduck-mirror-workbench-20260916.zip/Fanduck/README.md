# Fanduck · 镜像工作台源码

2026-09-16，经负责人确认公开。仅包含制作鸭子的物料及制作/调试工具；不含官网、App、产品运行时、失败的独立 IMU 或旧整机电源方案。

内容入口：
- 06_镜像工作台

## 来源与许可

官方模型来源：https://github.com/pollen-robotics/microduck_rl ，提交 d424a0c899f6b33cbd3daeb279913134349c0b63；模型及衍生件保留 CC BY-SA-NC 非商业许可，代码 Apache-2.0 不覆盖模型商业使用。原文见 LICENSES/官方模型许可依据。

HAT 来源：https://github.com/pollen-robotics/elec_RPI_Robot_HAT ，提交 23eab11927f95ceca0dfa35bf182caeb7db39ea0；其原 LICENSE 和第三方署名保留于板件包。触点板、NFC 与制作工具为本项目工程版本，不冒充官方原版。公开资料不等于完整开源硬件或商业生产授权。

文件来源及 SHA-256 见 SOURCES.json 与 SHA256SUMS.txt。板件 CAD 可能需要另行取得许可明确的外部 KiCad 库。制造包历史说明不代表新的生产或通电授权。

## 安全边界

打印件不是原厂生产图纸；当前修正版的数字检查不替代实物配合验收。相机、总线、供电的检查与停止条件见相应资料。不能将 2S 电池直接给额定 3.7–6.0 V 的零售 XL330 供电。本包不提供已经完成的新整机电源或身体姿态方案。镜像工作台默认不连接硬件、相机关闭，34 项离线测试不等于实机验收。

官网：https://duck.fandcode.com/#downloads
