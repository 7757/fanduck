#!/usr/bin/env bash
# Stop only this site's camera session; never stop robotd, padd or official media.
set -euo pipefail
[[ "${MICRODUCK_ENABLE_CAMERA:-0}" == 1 ]] || exit 0
SSH_KEY="${MICRODUCK_SSH_KEY:-$HOME/.ssh/microduck_ed25519}"
KNOWN_HOSTS="${MICRODUCK_KNOWN_HOSTS:-$HOME/.ssh/microduck_known_hosts}"
HOST_ALIAS="${MICRODUCK_HOST_ALIAS:-microduck}"
PROJECT_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
LABEL="com.microduck.live-video.tunnel"
launchctl remove "$LABEL" 2>/dev/null || true
if [[ -r "$SSH_KEY" && -r "$KNOWN_HOSTS" ]]; then
  if RADXA_HOST=$(python3 "$PROJECT_ROOT/scripts/resolve_microduck_host.py" 2>/dev/null); then
    ssh -i "$SSH_KEY" \
      -o IdentitiesOnly=yes \
      -o "UserKnownHostsFile=$KNOWN_HOSTS" \
      -o "HostKeyAlias=$HOST_ALIAS" -o StrictHostKeyChecking=yes \
      -o BatchMode=yes -o ConnectTimeout=6 "root@$RADXA_HOST" \
      'systemctl stop microduck-live-video-guard.service microduck-live-video-media.service microduck-live-video-3a.service microduck-live-video-status.service 2>/dev/null || true' || true
  fi
fi
echo '合并页面的相机取流已停止。'
