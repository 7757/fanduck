#!/usr/bin/env bash
# Start only the head-camera producer and loopback signal/status tunnel.
set -euo pipefail

if [[ "${MICRODUCK_ENABLE_CAMERA:-0}" != 1 ]]; then
  echo '相机默认关闭；确认硬件安全后设置 MICRODUCK_ENABLE_CAMERA=1。' >&2
  exit 2
fi

PROJECT_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
RESOLVER="$PROJECT_ROOT/scripts/resolve_microduck_host.py"
SOURCE="$PROJECT_ROOT/tools/microduck-live-video"
STATUS_SOURCE="$PROJECT_ROOT/tools/microduck-observer/radxa_status_server.py"
SSH_KEY="${MICRODUCK_SSH_KEY:-$HOME/.ssh/microduck_ed25519}"
KNOWN_HOSTS="${MICRODUCK_KNOWN_HOSTS:-$HOME/.ssh/microduck_known_hosts}"
HOST_ALIAS="${MICRODUCK_HOST_ALIAS:-microduck}"
LABEL="com.microduck.live-video.tunnel"
RUNTIME_DIR="/tmp/microduck-live-video-$(id -u)"
SESSION_MINUTES="${MICRODUCK_VIDEO_MINUTES:-10}"
REMOTE_DIR="/run/microduck-live-video"
SSH_OPTS=(-i "$SSH_KEY" -o IdentitiesOnly=yes -o UserKnownHostsFile="$KNOWN_HOSTS"
  -o "HostKeyAlias=$HOST_ALIAS" -o StrictHostKeyChecking=yes -o BatchMode=yes
  -o ConnectTimeout=6)

case "$SESSION_MINUTES" in ''|*[!0-9]*) echo '视频会话必须是 1–30 分钟。' >&2; exit 2 ;; esac
if (( SESSION_MINUTES < 1 || SESSION_MINUTES > 30 )); then
  echo '视频会话必须是 1–30 分钟。' >&2; exit 2
fi
for required in ssh scp python3 launchctl; do command -v "$required" >/dev/null; done
[[ -r "$SSH_KEY" && -r "$KNOWN_HOSTS" && -r "$STATUS_SOURCE" ]]
RADXA_HOST=$(python3 "$RESOLVER")
mkdir -p "$RUNTIME_DIR"
chmod 700 "$RUNTIME_DIR"

job_is_loaded() { launchctl print "gui/$(id -u)/$LABEL" >/dev/null 2>&1; }
port_is_open() {
  python3 - "$1" <<'PY'
import socket,sys
with socket.create_connection(("127.0.0.1", int(sys.argv[1])), timeout=.3): pass
PY
}

REMOTE_ACTIVE=0
if ssh "${SSH_OPTS[@]}" "root@$RADXA_HOST" \
  'systemctl is-active --quiet microduck-live-video-guard.service && systemctl is-active --quiet microduck-live-video-status.service'; then
  REMOTE_ACTIVE=1
fi

if (( ! REMOTE_ACTIVE )); then
  if job_is_loaded; then launchctl remove "$LABEL" 2>/dev/null || true; fi
  # The old observer and the official media stack have different ownership and
  # must be stopped by their owners before this camera-only session starts.
  if port_is_open 18443 2>/dev/null || port_is_open 18092 2>/dev/null; then
    echo '本机视频隧道端口已被其他会话占用。' >&2
    exit 1
  fi
  ssh "${SSH_OPTS[@]}" "root@$RADXA_HOST" "install -d -m 0700 '$REMOTE_DIR'"
  scp "${SSH_OPTS[@]}" -q \
    "$SOURCE/media.toml" "$SOURCE/radxa_guard.sh" \
    "$SOURCE/microduck-live-video-3a.service" \
    "$SOURCE/microduck-live-video-media.service" \
    "$STATUS_SOURCE" "root@$RADXA_HOST:$REMOTE_DIR/"
  ssh "${SSH_OPTS[@]}" "root@$RADXA_HOST" \
    "SESSION_MINUTES='$SESSION_MINUTES' REMOTE_DIR='$REMOTE_DIR' bash -s" <<'REMOTE'
set -euo pipefail
for unit in mediad.service rkaiq_3A.service microduck-observe-guard.service \
  microduck-observe-media.service microduck-observe-rkaiq.service \
  ducklink-camera-media.service ducklink-camera-3a.service; do
  if systemctl is-active --quiet "$unit"; then
    echo "相机已有其他使用者：$unit" >&2
    exit 1
  fi
done
if fuser /dev/video0 >/dev/null 2>&1; then
  echo '相机采集设备正被其他进程使用。' >&2
  exit 1
fi
temperature=0
valid=0
for zone in /sys/class/thermal/thermal_zone*; do
  [[ -r "$zone/temp" ]] || continue
  read -r current <"$zone/temp" || continue
  case "$current" in ''|*[!0-9]*) continue ;; esac
  valid=1
  (( current > temperature )) && temperature=$current
done
if (( ! valid )); then
  echo '无法读取主控温度，拒绝开启视频会话。' >&2
  exit 1
fi

install -m 0755 "$REMOTE_DIR/radxa_guard.sh" /run/microduck-live-video-guard.sh
install -m 0755 "$REMOTE_DIR/radxa_status_server.py" /run/microduck-live-video-status.py
install -m 0644 "$REMOTE_DIR/microduck-live-video-3a.service" /run/systemd/system/microduck-live-video-3a.service
install -m 0644 "$REMOTE_DIR/microduck-live-video-media.service" /run/systemd/system/microduck-live-video-media.service
systemctl daemon-reload
# A previous short session may have ended while its status endpoint remains
# loaded. These are only this viewer's transient units; never touch official
# media or motion services.
systemctl stop microduck-live-video-status.service microduck-live-video-guard.service \
  microduck-live-video-media.service microduck-live-video-3a.service 2>/dev/null || true
systemctl reset-failed microduck-live-video-3a.service microduck-live-video-media.service \
  microduck-live-video-guard.service microduck-live-video-status.service 2>/dev/null || true
systemctl daemon-reload
rm -f /run/microduck-live-video-state.json
systemd-run --quiet --unit=microduck-live-video-status --collect \
  --property="User=radxa" --property="RuntimeMaxSec=$((SESSION_MINUTES * 60 + 60))s" \
  /usr/bin/python3 /run/microduck-live-video-status.py \
    --host 127.0.0.1 --port 18081 --profile live \
    --state-file /run/microduck-live-video-state.json \
    --warning-temp-c 75 --stop-temp-c 90
systemd-run --quiet --unit=microduck-live-video-guard --collect \
  --property="RuntimeMaxSec=$((SESSION_MINUTES * 60 + 30))s" \
  /bin/bash /run/microduck-live-video-guard.sh 90000 \
    "$((SESSION_MINUTES * 60))" /run/microduck-live-video-state.json \
    75000 10 "$REMOTE_DIR/media.toml"
for attempt in {1..40}; do
  if systemctl is-active --quiet microduck-live-video-media.service \
    && ss -ltn | grep -q '127.0.0.1:8443' \
    && ss -ltn | grep -q '127.0.0.1:18081'; then
    echo '头部相机已开启；运动控制服务未被本脚本启停。'
    exit 0
  fi
  if ss -ltn | grep -q '127.0.0.1:18081' \
    && grep -q '"phase":"cooling"' /run/microduck-live-video-state.json 2>/dev/null; then
    echo '主控正在降温；达到75°C并稳定10秒后将自动开启头部相机。'
    exit 0
  fi
  if ! systemctl is-active --quiet microduck-live-video-guard.service; then break; fi
  sleep .5
done
journalctl -u microduck-live-video-guard.service -u microduck-live-video-media.service -n 25 --no-pager >&2 || true
echo '头部相机未能启动。' >&2
exit 1
REMOTE
fi

if job_is_loaded; then
  if launchctl print "gui/$(id -u)/$LABEL" 2>/dev/null | grep -F -- "root@$RADXA_HOST" >/dev/null \
    && port_is_open 18443 2>/dev/null && port_is_open 18092 2>/dev/null; then
    echo '复用头部相机视频隧道。'
    exit 0
  fi
  launchctl remove "$LABEL" 2>/dev/null || true
fi
if port_is_open 18443 2>/dev/null || port_is_open 18092 2>/dev/null; then
  echo '本机视频隧道端口已被其他会话占用。' >&2
  exit 1
fi
SSH_BIN=$(command -v ssh)
launchctl submit -l "$LABEL" -o "$RUNTIME_DIR/tunnel.log" -e "$RUNTIME_DIR/tunnel.log" -- \
  "$SSH_BIN" "${SSH_OPTS[@]}" -o ExitOnForwardFailure=yes \
    -o ServerAliveInterval=15 -o ServerAliveCountMax=3 -N \
    -L 127.0.0.1:18443:127.0.0.1:8443 \
    -L 127.0.0.1:18092:127.0.0.1:18081 "root@$RADXA_HOST"
for attempt in {1..40}; do
  if port_is_open 18443 2>/dev/null && port_is_open 18092 2>/dev/null; then
    echo '实时相机信令与温度状态已连接。'
    exit 0
  fi
  sleep .25
done
echo "视频隧道未就绪：$RUNTIME_DIR/tunnel.log" >&2
exit 1
