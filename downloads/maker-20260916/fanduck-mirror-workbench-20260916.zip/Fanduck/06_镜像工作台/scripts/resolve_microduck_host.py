#!/usr/bin/env python3
"""Find the local Microduck by its already trusted SSH host key."""

import base64
import concurrent.futures
import hashlib
import ipaddress
import os
import re
import socket
import subprocess
import sys
from pathlib import Path


HOST_ALIAS = os.environ.get("MICRODUCK_HOST_ALIAS", "microduck")
# DHCP addresses are hints only; discovery still verifies the pinned host key and
# scans the current subnet when an address changes.
RECENT_ADDRESSES = ()
KNOWN_HOSTS = Path(os.environ.get("MICRODUCK_KNOWN_HOSTS", str(Path.home() / ".ssh/microduck_known_hosts"))).expanduser()
EXPECTED_FINGERPRINT = os.environ.get("MICRODUCK_HOST_FINGERPRINT", "")
MAX_SCAN_HOSTS = 512


def key_fingerprint(key_blob):
    raw = base64.b64decode(key_blob, validate=True)
    return "SHA256:" + base64.b64encode(hashlib.sha256(raw).digest()).decode().rstrip("=")


def trusted_key():
    if not EXPECTED_FINGERPRINT.startswith("SHA256:"):
        raise ValueError("请先设置你自己的 MICRODUCK_HOST_FINGERPRINT 并独立核验主机密钥")
    keys = set()
    for line in KNOWN_HOSTS.read_text().splitlines():
        fields = line.split()
        if len(fields) >= 3 and HOST_ALIAS in fields[0].split(",") and fields[1] == "ssh-ed25519":
            if key_fingerprint(fields[2]) != EXPECTED_FINGERPRINT:
                raise ValueError("项目 known-hosts 中的瑞莎主机指纹不匹配")
            keys.add(fields[2])
    if len(keys) != 1:
        raise ValueError("项目 known-hosts 缺少唯一的瑞莎 ED25519 主机密钥")
    return keys.pop()


def local_network():
    route = subprocess.run(
        ["/sbin/route", "-n", "get", "default"],
        capture_output=True, text=True, check=True, timeout=3,
    ).stdout
    match = re.search(r"^\s*interface:\s*([\w.-]+)\s*$", route, re.MULTILINE)
    if not match:
        raise ValueError("无法识别当前默认网络接口")
    interface = match.group(1)
    details = subprocess.run(
        ["/sbin/ifconfig", interface],
        capture_output=True, text=True, check=True, timeout=3,
    ).stdout
    match = re.search(r"^\s*inet\s+(\d+\.\d+\.\d+\.\d+)\s+netmask\s+(0x[0-9a-fA-F]+|\d+\.\d+\.\d+\.\d+)", details, re.MULTILINE)
    if not match:
        raise ValueError("当前网络接口没有 IPv4 地址")
    address = ipaddress.IPv4Address(match.group(1))
    mask_text = match.group(2)
    mask = ipaddress.IPv4Address(int(mask_text, 16)) if mask_text.startswith("0x") else ipaddress.IPv4Address(mask_text)
    return address, ipaddress.IPv4Network((int(address) & int(mask), str(mask)))


def scanned_key_matches(address, expected_key):
    try:
        output = subprocess.run(
            ["/usr/bin/ssh-keyscan", "-T", "2", "-t", "ed25519", address],
            capture_output=True, text=True, timeout=4,
        ).stdout
    except (OSError, subprocess.TimeoutExpired):
        return False
    for line in output.splitlines():
        fields = line.split()
        if len(fields) >= 3 and fields[1] == "ssh-ed25519" and fields[2] == expected_key:
            return True
    return False


def port_22_open(address):
    try:
        with socket.create_connection((address, 22), timeout=0.5):
            return True
    except OSError:
        return False


def discover():
    expected_key = trusted_key()
    override = os.environ.get("MICRODUCK_HOST")
    if override:
        address = str(ipaddress.IPv4Address(override))
        if not scanned_key_matches(address, expected_key):
            raise ValueError("指定地址的 SSH 主机指纹不是已验证的瑞莎")
        return address

    own_address, network = local_network()
    for address in RECENT_ADDRESSES:
        if ipaddress.IPv4Address(address) in network and scanned_key_matches(address, expected_key):
            return address

    if network.num_addresses - 2 > MAX_SCAN_HOSTS:
        raise ValueError("当前子网过大，请用 MICRODUCK_HOST=瑞莎当前IP microduck monitor 指定地址")
    candidates = [str(address) for address in network.hosts() if address != own_address]
    with concurrent.futures.ThreadPoolExecutor(max_workers=64) as pool:
        open_hosts = list(pool.map(port_22_open, candidates))
    ssh_hosts = [address for address, is_open in zip(candidates, open_hosts) if is_open]
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        matches = list(pool.map(lambda address: scanned_key_matches(address, expected_key), ssh_hosts))
    found = [address for address, matches_key in zip(ssh_hosts, matches) if matches_key]
    if len(found) == 1:
        return found[0]
    if len(found) > 1:
        raise ValueError("发现多个使用瑞莎主机密钥的地址，请用 MICRODUCK_HOST 指定")
    raise ValueError("当前局域网未发现瑞莎；确认它已上电并连接同一 Wi-Fi 后重试")


if __name__ == "__main__":
    try:
        print(discover())
    except (ValueError, OSError, subprocess.SubprocessError) as exc:
        print(f"microduck 地址发现失败：{exc}", file=sys.stderr)
        sys.exit(1)
