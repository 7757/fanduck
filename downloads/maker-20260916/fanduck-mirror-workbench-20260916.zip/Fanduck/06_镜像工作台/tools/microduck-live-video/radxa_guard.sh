#!/usr/bin/env bash
# Camera-only session. The robot controller may run in parallel; this unit never
# starts/stops robotd, padd, ToF, or any servo device.
set -u

MAX_TEMP_MC="${1:?missing stop temperature}"
SESSION_SECONDS="${2:?missing session duration}"
STATE_FILE="${3:?missing state file}"
COOLDOWN_TEMP_MC="${4:-75000}"
COOLDOWN_STABLE_SECONDS="${5:-10}"
CONFIG_SOURCE="${6:?missing media config}"

STOP_REASON="starting"
PHASE="starting"
CAMERA_RUNNING=false
RESTART_COUNT=0
HOTTEST_MC=0
HOTTEST_ZONE="unknown"
TEMP_VALID=false
TRIGGER_MC=0
TRIGGER_ZONE="unknown"
COOLDOWN_REMAINING=0
BELOW_SINCE=-1

read_hottest_zone() {
  local zone value name
  HOTTEST_MC=0
  HOTTEST_ZONE="unknown"
  TEMP_VALID=false
  for zone in /sys/class/thermal/thermal_zone*; do
    [[ -r "$zone/temp" ]] || continue
    read -r value <"$zone/temp" || continue
    case "$value" in ''|*[!0-9]*) continue ;; esac
    TEMP_VALID=true
    if (( value > HOTTEST_MC )); then
      HOTTEST_MC=$value
      if [[ -r "$zone/type" ]]; then read -r name <"$zone/type" || name=unknown; else name=unknown; fi
      case "$name" in *[!A-Za-z0-9_.-]*) name=unknown ;; esac
      HOTTEST_ZONE=$name
    fi
  done
}

write_state() {
  local temporary="${STATE_FILE}.tmp.$$"
  printf '{"running":%s,"phase":"%s","reason":"%s","camera_running":%s,"max_millidegrees":%s,"hottest_zone":"%s","trigger_millidegrees":%s,"trigger_zone":"%s","cooldown_millidegrees":%s,"cooldown_stable_seconds":%s,"cooldown_remaining_seconds":%s,"restart_count":%s,"elapsed_seconds":%s,"limit_seconds":%s}\n' \
    "$1" "$PHASE" "$STOP_REASON" "$CAMERA_RUNNING" "$HOTTEST_MC" "$HOTTEST_ZONE" \
    "$TRIGGER_MC" "$TRIGGER_ZONE" "$COOLDOWN_TEMP_MC" "$COOLDOWN_STABLE_SECONDS" \
    "$COOLDOWN_REMAINING" "$RESTART_COUNT" "$SECONDS" "$SESSION_SECONDS" >"$temporary"
  chmod 0644 "$temporary"
  mv -f "$temporary" "$STATE_FILE"
}

stop_camera() {
  systemctl stop microduck-live-video-media.service microduck-live-video-3a.service 2>/dev/null || true
  CAMERA_RUNNING=false
}

other_camera_active() {
  local unit
  for unit in mediad.service rkaiq_3A.service microduck-observe-media.service \
    microduck-observe-rkaiq.service ducklink-camera-media.service ducklink-camera-3a.service; do
    if systemctl is-active --quiet "$unit"; then return 0; fi
  done
  return 1
}

start_camera() {
  local attempt
  if other_camera_active || fuser /dev/video0 >/dev/null 2>&1; then
    logger -t microduck-live-video "camera owner conflict; refusing capture"
    return 1
  fi
  install -d -m 0755 /run/microduck-live-media
  install -m 0644 "$CONFIG_SOURCE" /run/microduck-live-media/video.toml
  systemctl reset-failed microduck-live-video-3a.service microduck-live-video-media.service 2>/dev/null || true
  systemctl start microduck-live-video-3a.service || return 1
  sleep 1
  if ! systemctl start microduck-live-video-media.service; then stop_camera; return 1; fi
  for attempt in {1..30}; do
    if systemctl is-active --quiet microduck-live-video-media.service \
      && ss -ltn | grep -q '127.0.0.1:8443'; then
      CAMERA_RUNNING=true
      return 0
    fi
    sleep 0.5
  done
  stop_camera
  return 1
}

cleanup() {
  trap - EXIT
  stop_camera
  read_hottest_zone
  PHASE=stopped
  COOLDOWN_REMAINING=0
  write_state false
}
trap cleanup EXIT
trap 'STOP_REASON=terminated; exit 0' INT TERM

read_hottest_zone
if [[ "$TEMP_VALID" != true ]]; then STOP_REASON=temperature-unavailable; exit 1; fi
if (( HOTTEST_MC >= 78000 )); then
  PHASE=cooling
  STOP_REASON=thermal-start
  COOLDOWN_REMAINING=$COOLDOWN_STABLE_SECONDS
else
  write_state true
  if ! start_camera; then STOP_REASON=start-failed; exit 1; fi
  PHASE=running
  STOP_REASON=running
fi
write_state true

while sleep 3; do
  read_hottest_zone
  if [[ "$TEMP_VALID" != true ]]; then STOP_REASON=temperature-unavailable; exit 1; fi
  if (( SECONDS >= SESSION_SECONDS )); then STOP_REASON=time-limit; exit 0; fi
  if [[ "$PHASE" == running ]]; then
    if other_camera_active; then STOP_REASON=camera-owner-conflict; exit 1; fi
    if (( HOTTEST_MC >= MAX_TEMP_MC )); then
      TRIGGER_MC=$HOTTEST_MC
      TRIGGER_ZONE=$HOTTEST_ZONE
      STOP_REASON=thermal-stop
      PHASE=cooling
      BELOW_SINCE=-1
      COOLDOWN_REMAINING=$COOLDOWN_STABLE_SECONDS
      stop_camera
      write_state true
      continue
    fi
    if ! systemctl is-active --quiet microduck-live-video-media.service; then
      STOP_REASON=media-ended
      exit 1
    fi
    write_state true
    continue
  fi
  if (( HOTTEST_MC <= COOLDOWN_TEMP_MC )); then
    if (( BELOW_SINCE < 0 )); then BELOW_SINCE=$SECONDS; fi
    COOLDOWN_REMAINING=$((COOLDOWN_STABLE_SECONDS - (SECONDS - BELOW_SINCE)))
    (( COOLDOWN_REMAINING < 0 )) && COOLDOWN_REMAINING=0
  else
    BELOW_SINCE=-1
    COOLDOWN_REMAINING=$COOLDOWN_STABLE_SECONDS
  fi
  if (( COOLDOWN_REMAINING == 0 )); then
    PHASE=restarting
    write_state true
    if start_camera; then
      RESTART_COUNT=$((RESTART_COUNT + 1))
      STOP_REASON=running
      PHASE=running
      BELOW_SINCE=-1
    else
      STOP_REASON=restart-failed
      exit 1
    fi
  fi
  write_state true
done
