"""The SSH source consumes only the public robotd state/health shapes."""

import unittest

from radxa_reader import RadxaReader, REMOTE_READ_ONLY


class RadxaReaderTests(unittest.TestCase):
    def setUp(self):
        self.clock = [100.0]
        self.reader = RadxaReader(clock=lambda: self.clock[0])

    def test_remote_program_has_only_read_only_robot_methods(self):
        self.assertIn('connect("robot.subscribe", {"hz": 10})', REMOTE_READ_ONLY)
        self.assertIn('connect("robot.health", {})', REMOTE_READ_ONLY)
        self.assertNotIn('robot.enable', REMOTE_READ_ONLY)
        self.assertNotIn('robot.init', REMOTE_READ_ONLY)
        self.assertIn('if robotd_running() or os.path.exists(SOCKET):', REMOTE_READ_ONLY)
        self.assertIn('"/dev/ttyS2"', REMOTE_READ_ONLY)
        self.assertIn('bus.read_frame()', REMOTE_READ_ONLY)

    def test_state_and_health_are_expired_independently(self):
        self.reader._accept({"type": "state", "state": {
            "joints": [0.1] * 15, "safety": {"gravity": [0, 0, -1]},
        }})
        self.reader._accept({"type": "health", "health": {
            "healthy": True, "battery": {"volts": 5.1, "percent": 0},
            "motors": {"hottest": "mouth", "max_c": 32}, "cpu_temp_c": 66.0,
        }})
        live = self.reader.snapshot()
        self.assertTrue(live["fresh"])
        self.assertEqual(live["battery_v"], 5.1)
        self.assertEqual(live["gravity"], [0, 0, -1])
        self.assertEqual(live["motors"], [])  # robotd does not expose per-ID RAM data
        self.clock[0] += 0.7
        self.assertEqual(self.reader.snapshot()["status"], "stale")
        self.clock[0] += 2.5
        self.assertIsNone(self.reader.snapshot()["battery_v"])

    def test_invalid_or_partial_state_never_becomes_live(self):
        for joints in ([1] * 14, [float("nan")] * 15, [True] * 15):
            with self.subTest(joints=joints):
                self.reader._accept({"type": "state", "state": {"joints": joints}})
                self.assertFalse(self.reader.snapshot()["fresh"])
                self.assertIsNone(self.reader.snapshot()["joints"])

    def test_direct_frame_exposes_only_complete_torque_off_readings(self):
        motors = [{"id": motor_id, "torque": 0, "error": 0, "voltage_v": 5.1,
                   "temperature_c": 28, "current_ma": 0} for motor_id in
                  (20, 21, 22, 23, 24, 30, 31, 32, 33, 34, 10, 11, 12, 13, 14)]
        frame = {"joints": [0.2] * 15, "motors": motors}
        self.reader._accept({"type": "direct", "frame": frame})
        state = self.reader.snapshot()
        self.assertEqual(state["mode"], "direct")
        self.assertTrue(state["fresh"])
        self.assertEqual(state["battery_v"], 5.1)
        self.assertEqual(state["motor_thermal"]["max_c"], 28)
        self.assertEqual(len(state["motors"]), 15)
        motors[5]["error"] = 0x20
        self.reader._accept({"type": "direct", "frame": frame})
        self.assertEqual(self.reader.snapshot()["sequence"], 1)


if __name__ == "__main__":
    unittest.main()
