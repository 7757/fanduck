"""Read robotd IPC, or the idle motor bus, over pinned SSH.

The remote program sends only robot.subscribe/robot.health while robotd runs.
If robotd is stopped, it may use the same read-only bus transport as U2D2,
after checking the service, serial owner, bus quietness, torque and errors.
It is streamed over SSH stdin, so nothing is installed on the board.
"""

from __future__ import annotations

from collections import deque
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import subprocess
import threading
import time


ROOT = Path(__file__).resolve().parents[2]
JOINT_IDS = (20, 21, 22, 23, 24, 30, 31, 32, 33, 34, 10, 11, 12, 13, 14)
SSH_KEY = Path(os.environ.get("MICRODUCK_SSH_KEY", str(Path.home() / ".ssh/microduck_ed25519"))).expanduser()
KNOWN_HOSTS = Path(os.environ.get("MICRODUCK_KNOWN_HOSTS", str(Path.home() / ".ssh/microduck_known_hosts"))).expanduser()
HOST_ALIAS = os.environ.get("MICRODUCK_HOST_ALIAS", "microduck")

# This program is sent to `python3 -u -` through stdin after the host has been
# independently verified by the resolver and OpenSSH's pinned host-key check.
REMOTE_READ_ONLY = r'''
import json
import os
import socket
import subprocess
import sys
import threading
import time

SOCKET = "/run/robotd.sock"
out_lock = threading.Lock()

def emit(item):
    with out_lock:
        print(json.dumps(item, separators=(",", ":"), allow_nan=False), flush=True)

def connect(method, params):
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.settimeout(3)
    sock.connect(SOCKET)
    request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    sock.sendall((json.dumps(request, separators=(",", ":")) + "\n").encode())
    return sock

def health_loop():
    while True:
        try:
            with connect("robot.health", {}) as sock:
                line = sock.makefile("r").readline()
                message = json.loads(line)
                if isinstance(message.get("result"), dict):
                    emit({"type": "health", "health": message["result"]})
        except (OSError, ValueError, json.JSONDecodeError):
            pass
        time.sleep(1)

threading.Thread(target=health_loop, daemon=True).start()

def robotd_running():
    result = subprocess.run(["systemctl", "is-active", "robotd"],
                            capture_output=True, text=True, timeout=2)
    state = result.stdout.strip()
    if state == "active":
        return True
    if state == "inactive":
        return False
    raise RuntimeError("无法确认 robotd 已停止：" + state[:40])

def direct_read():
    if robotd_running() or os.path.exists(SOCKET):
        return
    owner_check = subprocess.run(["fuser", "/dev/ttyS2"], stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL, timeout=2)
    if owner_check.returncode != 1:
        raise RuntimeError("舵机串口已被占用；瑞莎直读未启动")
    # Public package uses the board's installed dynamixel-sdk and pyserial.
    namespace = {"__name__": "microduck_readonly_bus"}
    exec(compile(READ_ONLY_BUS_SOURCE, "readonly_bus.py", "exec"), namespace)
    bus = namespace["ReadOnlyBus"]("/dev/ttyS2")
    frames = 0
    try:
        bus.open()
        while not robotd_running() and not os.path.exists(SOCKET):
            frame = bus.read_frame()
            emit({"type": "direct", "frame": {
                "joints": frame["joints"], "motors": frame["motors"]}})
            frames += 1
            time.sleep(0.2)
    except namespace["ReadOnlyBusCommunicationError"] as error:
        return frames, str(error)
    finally:
        bus.close()
    return frames, None

communication_failures = 0
while True:
    try:
        with connect("robot.subscribe", {"hz": 10}) as sock:
            sock.settimeout(4)
            for line in sock.makefile("r"):
                message = json.loads(line)
                if message.get("method") == "robot.state" and isinstance(message.get("params"), dict):
                    emit({"type": "state", "state": message["params"]})
    except (OSError, ValueError, json.JSONDecodeError):
        if not robotd_running() and not os.path.exists(SOCKET):
            try:
                result = direct_read()
                if result is not None:
                    frames, communication_error = result
                    if communication_error:
                        communication_failures = 1 if frames else communication_failures + 1
                        if communication_failures >= 3:
                            raise RuntimeError("连续3次读包失败：" + communication_error)
                        emit({"type": "fault", "error": "主控只读串口读包失败，正在重连：" + communication_error[:100]})
                    else:
                        communication_failures = 0
            except Exception as error:
                emit({"type": "fault", "error": "瑞莎直读已停止：" + str(error)[:130]})
                # Torque, alert, ownership and identity faults latch. Repeated
                # communication failures also latch after three empty attempts.
                while not robotd_running() and not os.path.exists(SOCKET):
                    time.sleep(1)
        else:
            emit({"type": "fault", "error": "robotd 状态暂不可读"})
    time.sleep(2)
'''


def remote_program():
    source = (ROOT / "tools/microduck-joint-mirror/readonly_bus.py").read_text()
    return "READ_ONLY_BUS_SOURCE = " + repr(source) + "\n" + REMOTE_READ_ONLY


def valid_joints(value):
    return isinstance(value, list) and len(value) == 15 and all(
        isinstance(item, (float, int)) and not isinstance(item, bool) and math.isfinite(item)
        for item in value
    )


class RadxaReader:
    def __init__(self, clock=time.monotonic, resolver=None, popen=subprocess.Popen):
        self.clock = clock
        self.resolver = resolver or (ROOT / "scripts/resolve_microduck_host.py")
        self.popen = popen
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread = None
        self.process = None
        self.status = "disconnected"
        self.error = None
        self.joints = None
        self.gravity = None
        self.motors = []
        self.mode = None
        self.sequence = 0
        self.last_sample = None
        self.observed_at = None
        self.sample_times = deque(maxlen=40)
        self.health = None
        self.health_at = None
        self.host = None

    def connect(self):
        with self.lock:
            if self.thread and self.thread.is_alive():
                return False
            self.stop_event = threading.Event()
            self.status, self.error = "connecting", None
            self.joints = None
            self.gravity = None
            self.motors = []
            self.mode = None
            self.health = None
            self.health_at = None
            self.sample_times.clear()
            self.thread = threading.Thread(target=self._run, daemon=True)
            self.thread.start()
            return True

    def _run(self):
        while not self.stop_event.is_set():
            try:
                discovered = subprocess.run(
                    ["python3", str(self.resolver)], capture_output=True, text=True,
                    timeout=25, check=True,
                )
                host = discovered.stdout.strip()
                if not host or any(char not in "0123456789." for char in host):
                    raise RuntimeError("瑞莎地址发现返回无效地址")
                command = [
                    "/usr/bin/ssh", "-T", "-i", str(SSH_KEY),
                    "-o", "IdentitiesOnly=yes",
                    "-o", f"UserKnownHostsFile={KNOWN_HOSTS}",
                    "-o", f"HostKeyAlias={HOST_ALIAS}",
                    "-o", "StrictHostKeyChecking=yes", "-o", "BatchMode=yes",
                    "-o", "ConnectTimeout=6", "-o", "ServerAliveInterval=10",
                    "-o", "ServerAliveCountMax=3", f"root@{host}", "python3 -u -",
                ]
                process = self.popen(
                    command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT, text=True, bufsize=1,
                )
                with self.lock:
                    self.process, self.host = process, host
                    self.status = "connecting"
                process.stdin.write(remote_program())
                process.stdin.close()
                for line in process.stdout:
                    if self.stop_event.is_set():
                        break
                    try:
                        event = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    self._accept(event)
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=2)
                if not self.stop_event.is_set():
                    raise RuntimeError("瑞莎只读状态连接已断开")
            except (OSError, RuntimeError, subprocess.SubprocessError) as error:
                with self.lock:
                    if not self.stop_event.is_set():
                        self.status, self.error = "recovering", str(error)[:180]
            finally:
                if self.process is not None and self.process.poll() is None:
                    self.process.terminate()
                    try:
                        self.process.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        self.process.kill()
                        self.process.wait(timeout=2)
                with self.lock:
                    self.process = None
            self.stop_event.wait(3)
        with self.lock:
            self.status = "disconnected"

    def _accept(self, event):
        if not isinstance(event, dict):
            return
        now = self.clock()
        if event.get("type") == "state":
            state = event.get("state")
            if not isinstance(state, dict) or not valid_joints(state.get("joints")):
                return
            with self.lock:
                self.joints = state["joints"]
                self.motors = []
                self.mode = "robotd"
                gravity = state.get("safety", {}).get("gravity") if isinstance(state.get("safety"), dict) else None
                self.gravity = gravity if isinstance(gravity, list) and len(gravity) == 3 and all(
                    isinstance(v, (int, float)) and math.isfinite(v) for v in gravity
                ) else None
                self.sequence += 1
                self.last_sample = now
                self.observed_at = datetime.now(timezone.utc).isoformat()
                self.sample_times.append(now)
                self.status, self.error = "live", None
        elif event.get("type") == "direct":
            frame = event.get("frame")
            if not isinstance(frame, dict) or not valid_joints(frame.get("joints")):
                return
            motors = frame.get("motors")
            if not isinstance(motors, list) or len(motors) != 15 or any(
                not isinstance(motor, dict) or motor.get("id") != JOINT_IDS[index]
                or motor.get("torque") != 0 or motor.get("error") != 0
                or not isinstance(motor.get("voltage_v"), (int, float))
                or not math.isfinite(motor["voltage_v"])
                or not isinstance(motor.get("temperature_c"), int)
                or not isinstance(motor.get("current_ma"), int)
                for index, motor in enumerate(motors)
            ):
                return
            with self.lock:
                self.joints, self.motors = frame["joints"], motors
                self.gravity = None
                self.mode = "direct"
                self.sequence += 1
                self.last_sample = now
                self.observed_at = datetime.now(timezone.utc).isoformat()
                self.sample_times.append(now)
                self.status, self.error = "live", None
        elif event.get("type") == "health" and isinstance(event.get("health"), dict):
            with self.lock:
                self.health, self.health_at = event["health"], now
        elif event.get("type") == "fault":
            with self.lock:
                self.status = "recovering"
                self.error = str(event.get("error") or "瑞莎状态暂不可读")[:180]

    def disconnect(self):
        self.stop_event.set()
        with self.lock:
            process = self.process
        if process:
            process.terminate()
        if self.thread:
            self.thread.join(timeout=4)
        with self.lock:
            self.status = "disconnected"

    def snapshot(self):
        with self.lock:
            now = self.clock()
            age = max(0, now - self.last_sample) if self.last_sample is not None else None
            fresh = self.status == "live" and age is not None and age <= 0.6
            health = self.health if self.health_at is not None and now - self.health_at <= 3 else None
            times = self.sample_times
            span = times[-1] - times[0] if len(times) > 1 else 0
            battery = health.get("battery") if health else None
            direct = self.mode == "direct" and len(self.motors) == 15
            direct_voltage = sum(motor["voltage_v"] for motor in self.motors) / 15 if direct else None
            direct_temp = max(motor["temperature_c"] for motor in self.motors) if direct else None
            return {
                "app": "microduck-unified-observer-v1", "source": "radxa", "host": self.host,
                "mode": self.mode,
                "status": "stale" if self.status == "live" and not fresh else self.status,
                "fresh": fresh, "error": self.error, "sequence": self.sequence,
                "observed_at": self.observed_at,
                "dropped_frames": 0, "age_ms": round(age * 1000, 1) if age is not None else None,
                "hz": round((len(times) - 1) / span, 1) if span > 0 else 0,
                "joints": self.joints, "motors": self.motors if direct else [], "gravity": self.gravity,
                "battery_v": round(direct_voltage, 2) if direct else battery.get("volts") if isinstance(battery, dict) else None,
                "battery_percent": None if direct else battery.get("percent") if isinstance(battery, dict) else None,
                "motor_thermal": {"max_c": direct_temp} if direct else health.get("motors") if health else None,
                "cpu_temp_c": None if direct else health.get("cpu_temp_c") if health else None,
                "health": None if direct else health.get("healthy") if health else None,
                "body_orientation_measured": self.gravity is not None, "hardware_control_writes": 0,
                "telemetry_note": "逐台角度、电压、电流、温度来自瑞莎的只读串口采样；全台扭矩 OFF。" if direct else
                    "角度来自 robot.state；电压为 robot.health 的总线平均值。该接口不提供逐台电压、电流或扭矩寄存器。",
            }
