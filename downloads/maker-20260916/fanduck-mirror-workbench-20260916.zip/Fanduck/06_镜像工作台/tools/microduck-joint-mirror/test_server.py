"""Fault and freshness behavior without a serial device."""
import threading
import time
import unittest
from unittest.mock import MagicMock, patch

from server import Reader, SourceManager, video_available
from readonly_bus import ReadOnlyBusCommunicationError


class BlockingBus:
    def __init__(self, frame):
        self.frame = frame
        self.reached_second = threading.Event()
        self.release = threading.Event()
        self.closed = False
        self.calls = 0

    def open(self):
        return self

    def read_frame(self):
        self.calls += 1
        if self.calls == 1:
            return self.frame
        self.reached_second.set()
        self.release.wait(2)
        raise RuntimeError("USB disconnected")

    def close(self):
        self.closed = True


class ReaderTests(unittest.TestCase):
    def setUp(self):
        self.clock = [100.0]
        self.bus = BlockingBus({"monotonic": 100.0, "joints": [0.0] * 15, "motors": []})
        self.reader = Reader("/dev/fake", hz=25, bus_factory=lambda _port: self.bus, clock=lambda: self.clock[0])
        self.addCleanup(self.cleanup)

    def cleanup(self):
        self.bus.release.set()
        self.reader.disconnect()

    def wait_for_second_read(self):
        self.assertTrue(self.reader.connect())
        self.assertTrue(self.bus.reached_second.wait(1))

    def test_reader_stall_expires_last_frame_while_thread_still_running(self):
        self.wait_for_second_read()
        self.assertTrue(self.reader.snapshot()["fresh"])
        self.clock[0] += 0.4
        state = self.reader.snapshot()
        self.assertEqual(state["status"], "stale")
        self.assertFalse(state["fresh"])
        self.assertEqual(state["joints"], [0.0] * 15)
        self.assertFalse(self.reader.connect())  # never a second serial reader

    def test_usb_failure_closes_port_and_latches_without_retry(self):
        self.wait_for_second_read()
        self.bus.release.set()
        self.reader.thread.join(1)
        self.assertFalse(self.reader.thread.is_alive())
        state = self.reader.snapshot()
        self.assertFalse(state["fresh"])
        self.assertEqual(state["status"], "error")
        self.assertIn("USB disconnected", state["error"])
        self.assertTrue(self.bus.closed)
        self.assertEqual(self.bus.calls, 2)

    def test_disconnect_releases_the_only_port_without_motion_command(self):
        self.wait_for_second_read()
        self.reader.stop_event.set()
        self.bus.release.set()
        self.reader.disconnect()
        self.assertTrue(self.bus.closed)
        self.assertEqual(self.reader.snapshot()["status"], "disconnected")
        self.assertFalse(self.reader.snapshot()["fresh"])

    def test_one_corrupt_frame_reopens_then_publishes_only_new_valid_sample(self):
        reader = self.reader
        class FlakyBus:
            def __init__(self):
                self.opens = 0
                self.calls = 0
            def open(self):
                self.opens += 1
            def close(self):
                pass
            def read_frame(self):
                self.calls += 1
                if self.calls == 1:
                    raise ReadOnlyBusCommunicationError("bad CRC")
                reader.stop_event.set()
                return {"monotonic":100.0, "joints":[0.5]*15, "motors":[]}
        bus = FlakyBus()
        reader.bus_factory = lambda _port: bus
        reader.connect()
        reader.thread.join(2)
        self.assertFalse(reader.thread.is_alive())
        self.assertEqual(bus.opens, 2)
        self.assertEqual(reader.sequence, 1)
        self.assertEqual(reader.snapshot()["joints"], [0.5]*15)
        self.assertEqual(reader.dropped_frames, 1)

    def test_three_consecutive_communication_errors_stop_retrying(self):
        class FailedBus:
            def __init__(self):
                self.opens = 0
            def open(self):
                self.opens += 1
            def close(self):
                pass
            def read_frame(self):
                raise ReadOnlyBusCommunicationError("timeout")
        bus = FailedBus()
        self.reader.bus_factory = lambda _port: bus
        self.reader.connect()
        self.reader.thread.join(2)
        self.assertFalse(self.reader.thread.is_alive())
        self.assertEqual(bus.opens, 3)
        self.assertEqual(self.reader.snapshot()["status"], "error")
        self.assertEqual(self.reader.sequence, 0)


class SourceManagerTests(unittest.TestCase):
    def test_switch_releases_previous_reader_before_connecting_next(self):
        events = []

        class FakeReader:
            def __init__(self, name):
                self.name = name
                self.port = None
            def connect(self):
                events.append((self.name, "connect"))
            def disconnect(self):
                events.append((self.name, "disconnect"))
            def snapshot(self):
                return {"source": self.name}

        manager = SourceManager(FakeReader("u2d2"), FakeReader("radxa"), "radxa")
        with patch("server.detect_u2d2", return_value="/dev/cu.fake"):
            self.assertEqual(manager.switch("u2d2"), {"source": "u2d2"})
        self.assertEqual(events, [("radxa", "disconnect"), ("u2d2", "connect")])

    def test_missing_u2d2_keeps_radxa_source_and_reader(self):
        class FakeReader:
            def __init__(self, name):
                self.name = name
                self.disconnected = False
            def disconnect(self):
                self.disconnected = True
            def snapshot(self):
                return {"source": self.name}

        radxa = FakeReader("radxa")
        manager = SourceManager(FakeReader("u2d2"), radxa, "radxa")
        with patch("server.detect_u2d2", return_value=None):
            with self.assertRaisesRegex(ValueError, "未找到唯一 U2D2"):
                manager.switch("u2d2")
        self.assertEqual(manager.snapshot()["source"], "radxa")
        self.assertFalse(radxa.disconnected)


class VideoDiscoveryTests(unittest.TestCase):
    def test_local_signal_port_alone_does_not_claim_a_live_video_session(self):
        with patch("server.camera_status", return_value={"available": False}):
            self.assertFalse(video_available())

    def test_live_guard_and_media_are_required(self):
        with patch("server.camera_status", return_value={"available": True}):
            self.assertTrue(video_available())


if __name__ == "__main__":
    unittest.main()
