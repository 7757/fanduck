/* One local view for video and either read-only joint source. No motor intent. */
"use strict";

const $ = (id) => document.getElementById(id);
const view = new window.MicroduckPoseView($("duck"), { maxFps: 60, lightBackground: true });
const groups = [
  ["左腿", [[20, "髋部转向"], [21, "髋部侧摆"], [22, "髋部前后"], [23, "膝盖"], [24, "脚踝"]]],
  ["头颈", [[30, "颈部俯仰"], [31, "头部俯仰"], [32, "头部转向"], [33, "头部侧摆"], [34, "鸭嘴"]]],
  ["右腿", [[10, "髋部转向"], [11, "髋部侧摆"], [12, "髋部前后"], [13, "膝盖"], [14, "脚踝"]]],
];
const ids = groups.flatMap((group) => group[1].map((joint) => joint[0]));
const rows = [];
for (const [group, joints] of groups) {
  for (const [id, name] of joints) {
    const row = document.createElement("tr");
    const label = document.createElement("td");
    const number = document.createElement("span");
    number.className = "joint-id";
    number.textContent = id;
    const jointName = document.createElement("span");
    jointName.className = "joint-name";
    jointName.textContent = `${group} · ${name}`;
    label.append(number, jointName);
    row.append(label);
    for (let column = 0; column < 5; column++) {
      const cell = document.createElement("td");
      cell.textContent = "—";
      row.append(cell);
    }
    $("joints").append(row);
    rows.push(row);
  }
}

let latest = null;
let currentSource = null;
let lastSequence = -1;
let lastFreshAt = 0;
let modelError = null;
let actionError = null;
let pendingAction = false;

function metric(id, value, digits = 1) {
  $(id).textContent = Number.isFinite(value) ? Number(value).toFixed(digits) : "—";
}

function clearReadings() {
  for (const row of rows) {
    for (const cell of [...row.cells].slice(1)) {
      cell.textContent = "—";
      cell.className = "";
    }
  }
  $("joints").classList.add("stale");
  for (const id of ["voltage", "hz", "age", "motor-temp", "cpu-temp"]) $(id).textContent = "—";
}

function showUnavailable(message) {
  view.setUnavailable();
  $("connection").className = "badge";
  $("connection").textContent = message;
  $("pose-label").textContent = view.hasSample ? "最后一帧 · 非实时" : "等待实物读数";
  $("preview").hidden = false;
  $("preview").textContent = view.hasSample ? "数据已停止更新 · 当前模型为最后一帧" : "模型预览 · 尚未取得实物读数";
  clearReadings();
}

function render(state, transitMs) {
  latest = state;
  if (state.source !== currentSource) {
    currentSource = state.source;
    lastSequence = -1;
    lastFreshAt = 0;
    $("source").value = state.source;
    view.setUnavailable();
  }
  const validAngles = Array.isArray(state.joints) && state.joints.length === 15 && state.joints.every(Number.isFinite);
  const perMotor = state.source === "u2d2" || state.mode === "direct";
  const validU2d2 = !perMotor || (
    Array.isArray(state.motors) && state.motors.length === 15 &&
    state.motors.every((motor, index) => motor.id === ids[index] && motor.torque === 0 && motor.error === 0)
  );
  const age = state.age_ms === null ? Infinity : state.age_ms + transitMs;
  const ageLimit = state.source === "u2d2" ? 250 : 700;
  const fresh = state.fresh && validAngles && validU2d2 && age <= ageLimit;
  $("source-note").textContent = state.mode === "direct" ? "主控串口直读" : state.source === "radxa" ? "主控状态接口" : "U2D2 直读";
  $("orientation-note").textContent = state.body_orientation_measured ? "躯干姿态来自 IMU" : "躯干方向未测量";
  $("telemetry-note").textContent = state.telemetry_note || "等待数据来源";
  $("error").hidden = !state.error && !modelError && !actionError;
  $("error").textContent = modelError || actionError || state.error || "";
  const active = ["live", "stale", "connecting", "recovering"].includes(state.status);
  $("toggle").textContent = state.status === "connecting" ? "连接中…" : active ? "断开读取" : "重新连接";
  $("toggle").disabled = pendingAction || state.status === "connecting";

  if (!fresh) {
    const labels = {
      connecting: state.source === "radxa" ? "正在连接主控" : "正在连接 U2D2",
      recovering: "正在恢复连接", error: "读取已停止",
      stale: "数据已过期", disconnected: "已断开读取",
    };
    showUnavailable(labels[state.status] || "等待有效读数");
    return;
  }
  if (state.sequence !== lastSequence) {
    lastSequence = state.sequence;
    lastFreshAt = performance.now();
    view.setState(state.joints, state.gravity || [0, 0, -1]);
  }
  if (performance.now() - lastFreshAt > ageLimit) {
    showUnavailable("数据已过期");
    return;
  }
  $("connection").className = "badge live";
  $("connection").textContent = `实时 · 15 / 15`;
  $("pose-label").textContent = "实测关节姿态";
  $("preview").hidden = true;
  $("joints").classList.remove("stale");
  metric("voltage", state.battery_v, 2);
  metric("hz", state.hz, 1);
  metric("age", Math.round(age), 0);
  const hot = perMotor
    ? Math.max(...state.motors.map((motor) => motor.temperature_c).filter(Number.isFinite))
    : state.motor_thermal?.max_c;
  metric("motor-temp", hot, 1);
  metric("cpu-temp", state.cpu_temp_c, 1);
  state.joints.forEach((radians, index) => {
    const row = rows[index];
    const motor = perMotor ? state.motors[index] : null;
    row.cells[1].textContent = `${(radians * 180 / Math.PI).toFixed(1)}°`;
    row.cells[2].textContent = Number.isFinite(motor?.voltage_v) ? `${motor.voltage_v.toFixed(1)} V` : "—";
    row.cells[3].textContent = Number.isFinite(motor?.current_ma) ? `${motor.current_ma} mA` : "—";
    row.cells[4].textContent = Number.isFinite(motor?.temperature_c) ? `${motor.temperature_c} °C` : "—";
    row.cells[5].textContent = motor ? "OFF · 0" : "—";
    row.cells[5].className = motor ? "status-cell ok" : "status-cell";
  });
}

async function poll() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 1000);
  const started = performance.now();
  try {
    const response = await fetch("/api/state", { cache: "no-store", signal: controller.signal });
    if (!response.ok) throw new Error("本地数据服务暂不可用");
    render(await response.json(), performance.now() - started);
  } catch (_error) {
    showUnavailable("本地服务已断开");
    $("toggle").disabled = true;
  } finally {
    clearTimeout(timer);
    setTimeout(poll, document.hidden ? 500 : currentSource === "radxa" ? 100 : 40);
  }
}

async function sendAction(path, body = null) {
  const options = { method: "POST", headers: { "Content-Type": "application/json" } };
  if (body !== null) options.body = JSON.stringify(body);
  const response = await fetch(path, options);
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "操作失败");
  return result;
}

function showActionError(error) {
  actionError = error.message;
  $("error").hidden = false;
  $("error").textContent = actionError;
}

$("toggle").addEventListener("click", async () => {
  if (!latest || pendingAction) return;
  const active = ["live", "stale", "connecting", "recovering"].includes(latest.status);
  pendingAction = true;
  $("toggle").disabled = true;
  try { actionError = null; render(await sendAction(`/api/${active ? "disconnect" : "connect"}`), 0); }
  catch (error) { showActionError(error); }
  finally { pendingAction = false; }
});

$("source").addEventListener("change", async (event) => {
  const selected = event.target.value;
  if (pendingAction || selected === currentSource) return;
  pendingAction = true;
  $("source").disabled = true;
  try { actionError = null; render(await sendAction("/api/source", { source: selected }), 0); }
  catch (error) {
    $("source").value = currentSource;
    showActionError(error);
  } finally { pendingAction = false; $("source").disabled = false; }
});

for (const [name, azimuth] of [["front", 0], ["left", Math.PI / 2], ["right", -Math.PI / 2]]) {
  $(name).addEventListener("click", () => {
    document.querySelectorAll(".buttons button").forEach((button) => button.classList.toggle("active", button.id === name));
    view.azimuth = azimuth;
    view.elevation = 0.2;
    view.invalidate(true);
  });
}
$("reset").addEventListener("click", () => {
  document.querySelectorAll(".buttons button").forEach((button) => button.classList.toggle("active", button.id === "reset"));
  view.resetView();
});
$("duck").addEventListener("pointerdown", () => document.querySelectorAll(".buttons button").forEach((button) => button.classList.remove("active")));

view.load("/duck.bin").catch((error) => {
  modelError = error.message;
  $("error").textContent = modelError;
  $("error").hidden = false;
});
poll();
