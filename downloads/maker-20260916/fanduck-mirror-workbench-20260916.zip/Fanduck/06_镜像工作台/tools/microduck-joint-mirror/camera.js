/* Receive the head camera track only. No robot RPC or control data is sent. */
"use strict";

(() => {
  const $ = (id) => document.getElementById(id);
  const video = $("camera-video");
  const canvas = $("camera-canvas");
  const rotationSelect = $("video-rotation");
  let ws = null;
  let pc = null;
  let sessionId = null;
  let producerId = null;
  let rotation = 90;
  let connected = false;
  let startPending = false;
  let lastPhase = "";
  let drawStarted = false;

  try {
    const savedRotation = localStorage.getItem("microduck-video-rotation");
    if (savedRotation !== null && ["0", "90", "180", "270"].includes(savedRotation)) {
      rotation = Number(savedRotation);
    }
  } catch (_error) { /* Storage may be unavailable in a private session. */ }
  rotationSelect.value = String(rotation);
  rotationSelect.addEventListener("change", () => {
    const nextRotation = Number(rotationSelect.value);
    if (![0, 90, 180, 270].includes(nextRotation)) return;
    rotation = nextRotation;
    try { localStorage.setItem("microduck-video-rotation", String(rotation)); }
    catch (_error) { /* The current page still keeps the selection. */ }
  });

  function message(title, detail) {
    $("video-status").textContent = title;
    $("video-empty-message").textContent = detail;
    if (!connected) $("video-empty").hidden = false;
  }

  function closeSignal() {
    if (pc) pc.close();
    pc = null;
    if (ws) ws.close();
    ws = null;
    sessionId = null;
    producerId = null;
    connected = false;
    drawStarted = false;
    video.srcObject = null;
    $("video-empty").hidden = false;
  }

  function send(packet) {
    if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(packet));
  }

  function connect() {
    if (ws || document.hidden) return;
    message("正在接收实时画面", "正在与头部摄像头协商视频连接…");
    ws = new WebSocket("ws://127.0.0.1:18443");
    ws.onopen = () => send({ type: "list" });
    ws.onerror = () => message("视频连接中断", "正在等待相机信令恢复…");
    ws.onclose = () => {
      closeSignal();
      message("视频连接中断", "相机暂停或网络中断；恢复后自动重连。");
    };
    ws.onmessage = async (event) => {
      let packet;
      try { packet = JSON.parse(event.data); } catch { return; }
      if (packet.type === "welcome") {
        send({ type: "list" });
      } else if (packet.type === "list") {
        const producer = packet.producers?.[0];
        if (!producer) {
          setTimeout(() => send({ type: "list" }), 1200);
        } else if (producer.id !== producerId) {
          producerId = producer.id;
          send({ type: "startSession", peerId: producer.id });
        }
      } else if (packet.type === "sessionStarted") {
        sessionId = packet.sessionId;
        createPeer();
      } else if (packet.type === "peer" && pc) {
        try {
          if (packet.sdp) {
            await pc.setRemoteDescription(packet.sdp);
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            send({ type: "peer", sessionId, sdp: { type: "answer", sdp: answer.sdp } });
          } else if (packet.ice) {
            await pc.addIceCandidate({
              candidate: packet.ice.candidate,
              sdpMLineIndex: packet.ice.sdpMLineIndex,
            });
          }
        } catch (error) {
          message("视频协商失败", error.message || "等待重新连接");
        }
      }
    };
  }

  function createPeer() {
    pc = new RTCPeerConnection();
    pc.onicecandidate = (event) => {
      if (event.candidate) send({
        type: "peer", sessionId,
        ice: { candidate: event.candidate.candidate,
          sdpMLineIndex: event.candidate.sdpMLineIndex },
      });
    };
    pc.onconnectionstatechange = () => {
      if (pc?.connectionState === "failed") {
        closeSignal();
        message("视频连接失败", "正在重新连接头部摄像头…");
      }
    };
    pc.ontrack = (event) => {
      if (event.track.kind !== "video") return;
      video.srcObject = event.streams[0];
      video.play().catch(() => {});
      connected = true;
      $("video-empty").hidden = false;
      message("正在等待首帧画面", "视频已连接，等待摄像头送来首帧…");
      if (!drawStarted) { drawStarted = true; drawFrame(); }
    };
    // The media producer offers a data channel; close it without sending a
    // single RPC. The producer itself is sandboxed away from robot IPC.
    pc.ondatachannel = (event) => event.channel.close();
  }

  function drawFrame() {
    if (video.readyState >= 2 && video.videoWidth && video.videoHeight && connected) {
      const swapped = rotation === 90 || rotation === 270;
      const outW = swapped ? video.videoHeight : video.videoWidth;
      const outH = swapped ? video.videoWidth : video.videoHeight;
      const ratio = Math.min(window.devicePixelRatio || 1, 1.25);
      const width = Math.max(1, Math.round(canvas.clientWidth * ratio));
      const height = Math.max(1, Math.round(canvas.clientHeight * ratio));
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }
      const ctx = canvas.getContext("2d", { alpha: false });
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.fillStyle = "#030405";
      ctx.fillRect(0, 0, width, height);
      const scale = Math.min(width / outW, height / outH);
      const fitW = outW * scale;
      const fitH = outH * scale;
      ctx.save();
      ctx.translate((width - fitW) / 2, (height - fitH) / 2);
      if (rotation === 90) { ctx.translate(fitW, 0); ctx.rotate(Math.PI / 2); }
      else if (rotation === 180) { ctx.translate(fitW, fitH); ctx.rotate(Math.PI); }
      else if (rotation === 270) { ctx.translate(0, fitH); ctx.rotate(-Math.PI / 2); }
      ctx.drawImage(video, 0, 0, swapped ? fitH : fitW, swapped ? fitW : fitH);
      ctx.restore();
      $("video-empty").hidden = true;
      $("video-status").textContent = "实时画面已连接";
      $("camera-meta").textContent = `头部摄像头 · ${outW}×${outH} 实时画面 · 旋转 ${rotation}°`;
    }
    if (video.requestVideoFrameCallback) video.requestVideoFrameCallback(drawFrame);
    else requestAnimationFrame(drawFrame);
  }

  async function start() {
    if (startPending || document.hidden) return;
    startPending = true;
    try {
      const response = await fetch("/api/video/start", { method: "POST" });
      if (!response.ok) throw new Error(`视频启动请求失败：HTTP ${response.status}`);
    } catch (error) {
      message("相机暂不可用", error.message || "无法启动");
    } finally { startPending = false; }
  }

  async function poll() {
    if (!document.hidden) {
      try {
        const response = await fetch("/api/video", { cache: "no-store" });
        const state = await response.json();
        if (state.available) {
          if (!ws) connect();
        } else {
          if (ws) closeSignal();
          const reason = state.reason;
          const descriptions = {
            "thermal-stop": "主控温度达到保护线，降温后自动恢复画面。",
            "thermal-start": "主控温度偏高，降至 75°C 并稳定 10 秒后自动开流。",
            "time-limit": "本轮视频会话已到时；刷新页面可开启新会话。",
            "camera-owner-conflict": "摄像头正在被其他程序使用。",
            "start-failed": "相机启动失败，请查看本机视频日志。",
            "temperature-unavailable": "无法读取主控温度，视频已停流。",
          };
          const detail = state.error || descriptions[reason] || "正在等待相机启动…";
          message(state.phase === "starting" ? "正在开启头部相机" : "相机画面暂不可用", detail);
          if (lastPhase === "unavailable" && state.phase === "unavailable" && !state.error) start();
        }
        lastPhase = state.phase;
      } catch (_error) { message("视频状态暂不可读", "正在重试本地连接…"); }
    }
    setTimeout(poll, document.hidden ? 5000 : 2000);
  }

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) closeSignal();
    else { start(); poll(); }
  });
  start();
  poll();
})();
