"""U2D2 encoder feedback only; this module cannot transmit control-table writes."""

from __future__ import annotations

import fcntl
import math
import termios
import threading
import time

from dynamixel_sdk import COMM_RX_CORRUPT, COMM_RX_TIMEOUT, COMM_SUCCESS, PacketHandler, PortHandler
from serial.tools import list_ports as serial_ports


JOINT_IDS = (20, 21, 22, 23, 24, 30, 31, 32, 33, 34, 10, 11, 12, 13, 14)
MODEL_NUMBER = 1200
FRAME_ADDRESS = 64
FRAME_LENGTH = 83  # Registers 64 through 146: status, motion, voltage, temperature.
MAX_FRAME_AGE_SECONDS = 0.250
READ_INSTRUCTIONS = frozenset((0x01, 0x02, 0x82))  # PING, READ, SYNC_READ.


class ReadOnlyBusError(RuntimeError):
    pass


class ReadOnlyBusCommunicationError(ReadOnlyBusError):
    """A corrupted or missing response, never a reported hardware/torque fault."""
    pass


def list_ports():
    """Enumerate OS metadata without opening a serial device."""
    return [
        {
            "device": port.device,
            "description": port.description,
            "serial_number": port.serial_number,
            "vid": port.vid,
            "pid": port.pid,
        }
        for port in sorted(serial_ports.comports(), key=lambda item: item.device)
    ]


class _ReadOnlyPortHandler(PortHandler):
    def writePort(self, packet):
        """The SDK's final output boundary: reject every motion/configuration opcode."""
        try:
            raw = bytes(packet)
        except (TypeError, ValueError) as error:
            raise ReadOnlyBusError("Invalid outgoing DYNAMIXEL packet") from error
        if (
            len(raw) < 10
            or raw[:4] != b"\xff\xff\xfd\x00"
            or int.from_bytes(raw[5:7], "little") + 7 != len(raw)
        ):
            raise ReadOnlyBusError("Malformed outgoing DYNAMIXEL packet")
        if raw[7] not in READ_INSTRUCTIONS:
            raise ReadOnlyBusError(f"Read-only transport rejected instruction 0x{raw[7]:02x}")
        return super().writePort(raw)

    def getCurrentTime(self):
        # SDK timeouts otherwise use wall time, which can jump while a read is pending.
        return time.monotonic() * 1000.0


def _signed_position(data):
    return int.from_bytes(bytes(data), byteorder="little", signed=True)


class ReadOnlyBus:
    """One exclusive host connection, fixed IDs, and no cached feedback fallback.

    ``monotonic`` is the start of a completed acquisition, conservatively dating its
    oldest possible sample. Consumers must also expire frames if their reader stops.
    Read requests do transmit UART bytes; they never change a control-table register.
    """

    def __init__(self, port, baud=1_000_000):
        if not isinstance(port, str) or not port:
            raise ValueError("A serial port path is required")
        if isinstance(baud, bool) or not isinstance(baud, int) or baud <= 0:
            raise ValueError("The host baud rate must be a positive integer")
        self.port_name = port
        self.baud = baud
        self._port = None
        self._packet = PacketHandler(2.0)
        self._offsets = {}
        self._lock = threading.Lock()

    def open(self):
        with self._lock:
            if self._port is not None:
                raise ReadOnlyBusError("The read-only bus is already open")
            port = _ReadOnlyPortHandler(self.port_name)
            self._port = port
            try:
                # setBaudRate opens the host port itself. Do not reopen after locking it.
                if not port.setBaudRate(self.baud):
                    raise ReadOnlyBusError(f"Cannot open {self.port_name} at {self.baud} baud")
                port.ser.exclusive = True
                fcntl.ioctl(port.ser.fileno(), termios.TIOCEXCL)
                self._require_quiet_bus()
                # SDK RX otherwise busy-polls pyserial with timeout=0. A short
                # blocking read releases the GIL while USB delivers the packet,
                # leaving the HTTP/UI thread responsive. SDK still checks CRC and
                # its own packet deadline; this changes only the Mac read behavior.
                port.ser.timeout = 0.010
                offsets = {}
                for motor_id in JOINT_IDS:
                    model = int.from_bytes(self._read_register(motor_id, 0, 2), "little")
                    if model != MODEL_NUMBER:
                        raise ReadOnlyBusError(
                            f"ID {motor_id}: model {model}, expected XL330-M288 model {MODEL_NUMBER}"
                        )
                    offsets[motor_id] = _signed_position(self._read_register(motor_id, 20, 4))
                self._offsets = offsets
                return self
            except BaseException:
                self._close_unlocked()
                raise

    def _require_quiet_bus(self):
        """Listen before transmitting. An active second host must stop this reader."""
        def listen(seconds):
            received = bytearray()
            deadline = time.monotonic() + seconds
            while time.monotonic() < deadline:
                received.extend(self._port.ser.read(max(1, self._port.ser.in_waiting)))
                time.sleep(0.005)
            return bytes(received)

        settling = listen(0.3)
        quiet = listen(2.0)
        # This adapter previously emitted a lone FC during opening. It is not a
        # valid DYNAMIXEL packet. Any other startup traffic, or later byte, rejects.
        if settling not in (b"", b"\xfc") or quiet:
            raise ReadOnlyBusError("总线上已有数据，已停止读取；请关闭其他总线程序")

    def _require_empty_input(self):
        if self._port.ser.in_waiting:
            raise ReadOnlyBusError("收到非本次请求的数据，已停止读取；请关闭其他总线程序")

    def _check_communication(self, result, context):
        if result != COMM_SUCCESS:
            error_type = ReadOnlyBusCommunicationError if result in (COMM_RX_CORRUPT, COMM_RX_TIMEOUT) else ReadOnlyBusError
            raise error_type(f"{context}: {self._packet.getTxRxResult(result)}")

    def _receive(self, expected_ids, length):
        received = {}
        expected = set(expected_ids)
        for _ in expected_ids:
            packet, result = self._packet.rxPacket(self._port, False)
            missing = sorted(expected - received.keys())
            self._check_communication(result, f"Read failed; waiting for IDs {missing}")
            if len(packet) < 11 or bytes(packet[:4]) != b"\xff\xff\xfd\x00":
                raise ReadOnlyBusError("Malformed status packet")
            motor_id = packet[4]
            if motor_id not in expected:
                raise ReadOnlyBusError(f"Unexpected ID {motor_id} in read response")
            if motor_id in received:
                raise ReadOnlyBusError(f"Duplicate ID {motor_id} in read response")
            if packet[7] != 0x55:
                raise ReadOnlyBusError(f"ID {motor_id}: response is not a status packet")
            if packet[8] != 0:
                raise ReadOnlyBusError(f"ID {motor_id}: status error 0x{packet[8]:02x}")
            declared = int.from_bytes(bytes(packet[5:7]), "little")
            # SDK verifies CRC before removing stuffing. Its unstuffed list may retain
            # old trailing bytes, but the updated LENGTH describes the valid prefix.
            if declared != length + 4 or len(packet) < declared + 7:
                raise ReadOnlyBusError(
                    f"ID {motor_id}: wrong status length {declared}; expected {length + 4}"
                )
            received[motor_id] = bytes(packet[9:9 + length])
        if received.keys() != expected:
            raise ReadOnlyBusError(f"Missing IDs {sorted(expected - received.keys())}")
        return received

    def _read_register(self, motor_id, address, length):
        self._require_empty_input()
        result = self._packet.readTx(self._port, motor_id, address, length)
        self._check_communication(result, f"ID {motor_id}: read request at {address}")
        return self._receive((motor_id,), length)[motor_id]

    def read_frame(self):
        with self._lock:
            if self._port is None or len(self._offsets) != len(JOINT_IDS):
                raise ReadOnlyBusError("The read-only bus is not open")
            started = time.monotonic()
            try:
                self._require_empty_input()
                result = self._packet.syncReadTx(
                    self._port, FRAME_ADDRESS, FRAME_LENGTH,
                    list(JOINT_IDS), len(JOINT_IDS), False,
                )
                self._check_communication(result, "Synchronous read request")
                blocks = self._receive(JOINT_IDS, FRAME_LENGTH)
                elapsed = time.monotonic() - started
                if elapsed < 0.0 or elapsed > MAX_FRAME_AGE_SECONDS:
                    raise ReadOnlyBusError(f"Stale read: acquisition took {elapsed:.3f} seconds")
                motors = []
                joints = []
                for motor_id in JOINT_IDS:
                    block = blocks[motor_id]
                    torque, hardware_error = block[0], block[70 - FRAME_ADDRESS]
                    if torque != 0:
                        raise ReadOnlyBusError(f"ID {motor_id}: torque is ON or invalid ({torque})")
                    if hardware_error != 0:
                        raise ReadOnlyBusError(f"ID {motor_id}: hardware error 0x{hardware_error:02x}")
                    raw = _signed_position(block[132 - FRAME_ADDRESS:136 - FRAME_ADDRESS])
                    current_ma = int.from_bytes(block[126 - FRAME_ADDRESS:128 - FRAME_ADDRESS], "little", signed=True)
                    voltage_v = int.from_bytes(block[144 - FRAME_ADDRESS:146 - FRAME_ADDRESS], "little") * 0.1
                    temperature_c = block[146 - FRAME_ADDRESS]
                    # Present Position already includes Homing Offset. Preserve signed
                    # multi-turn counts while torque is OFF; do not wrap or zero them.
                    joints.append(raw * (2.0 * math.pi / 4096.0) - math.pi)
                    motors.append({
                        "id": motor_id, "raw": raw, "offset": self._offsets[motor_id],
                        "torque": torque, "error": hardware_error,
                        "current_ma": current_ma,
                        "voltage_v": round(voltage_v, 1),
                        "temperature_c": temperature_c,
                    })
                return {"joints": joints, "motors": motors, "monotonic": started}
            except ReadOnlyBusError:
                raise
            except Exception as error:
                raise ReadOnlyBusError(f"Serial read failed: {error}") from error

    def _close_unlocked(self):
        port, self._port = self._port, None
        self._offsets = {}
        if port is not None and port.ser is not None:
            port.closePort()

    def close(self):
        with self._lock:
            self._close_unlocked()
