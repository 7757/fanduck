"""Public package defaults: no credentials, network, camera or serial IO."""
import importlib.util
import os
from pathlib import Path
import subprocess
import unittest
from unittest.mock import patch

import live_video

ROOT = Path(__file__).resolve().parents[2]


class PublicDefaultsTests(unittest.TestCase):
    def test_camera_status_does_not_query_local_or_remote_service_by_default(self):
        with patch.dict(os.environ, {}, clear=True), patch("live_video.urlopen") as query:
            self.assertEqual(live_video.camera_status()["phase"], "disabled")
            query.assert_not_called()

    def test_unconfigured_resolver_fails_before_any_network_scan(self):
        spec = importlib.util.spec_from_file_location("public_resolver", ROOT / "scripts/resolve_microduck_host.py")
        module = importlib.util.module_from_spec(spec)
        with patch.dict(os.environ, {}, clear=True):
            spec.loader.exec_module(module)
        with patch.object(module, "local_network") as network, patch.object(module, "scanned_key_matches") as scan:
            with self.assertRaisesRegex(ValueError, "MICRODUCK_HOST_FINGERPRINT"):
                module.discover()
            network.assert_not_called()
            scan.assert_not_called()

    def test_camera_scripts_exit_before_remote_actions_without_opt_in(self):
        for name, expected in [("start_microduck_live_video.sh", 2), ("stop_microduck_live_video.sh", 0)]:
            with self.subTest(script=name):
                # Empty PATH and environment: any accidental launchctl/ssh would fail.
                result = subprocess.run(["/bin/bash", str(ROOT / "scripts" / name)],
                                        env={"PATH": ""}, capture_output=True, text=True, timeout=3)
                self.assertEqual(result.returncode, expected)

    def test_viewer_static_dependencies_are_present(self):
        for name in ["tools/microduck-joint-mirror/index.html",
                     "tools/microduck-joint-mirror/app.js",
                     "tools/microduck-joint-mirror/camera.js",
                     "tools/microduck-observer/duck-view.js",
                     "work/microduck-observer-assets/duck-web-mouth-v2.bin"]:
            self.assertTrue((ROOT / name).is_file(), name)
        with (ROOT / "work/microduck-observer-assets/duck-web-mouth-v2.bin").open("rb") as asset:
            self.assertEqual(asset.read(4), b"DHD2")


if __name__ == "__main__":
    unittest.main()
