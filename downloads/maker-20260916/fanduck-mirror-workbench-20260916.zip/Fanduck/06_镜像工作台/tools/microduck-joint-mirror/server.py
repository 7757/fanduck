#!/usr/bin/env python3
"""Unified local camera view, U2D2 telemetry, and read-only Radxa state.

Only the acquisition thread owns the serial bus. Browsers consume snapshots; a
GET never opens a device. Bad/missing packets get at most two fresh preflights;
hardware, identity and ownership faults latch until reconnect. The Radxa reader
uses only read-only robotd IPC when the controller owns the bus.
"""
from __future__ import annotations

import argparse
from collections import deque
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
from pathlib import Path
import signal
import threading
import time
from urllib.parse import urlsplit

from readonly_bus import MAX_FRAME_AGE_SECONDS, ReadOnlyBus, ReadOnlyBusCommunicationError, list_ports
from radxa_reader import RadxaReader
from live_video import LiveVideoManager, camera_status

ROOT = Path(__file__).resolve().parents[2]
APP = "microduck-unified-observer-v1"


class Reader:
    def __init__(self, port, hz=30.0, bus_factory=ReadOnlyBus, clock=time.monotonic):
        self.port, self.hz = port, hz
        self.bus_factory, self.clock = bus_factory, clock
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.thread = None
        self.status, self.error = "disconnected", None
        self.frame, self.sequence = None, 0
        self.sample_times = deque(maxlen=100)
        self.observed_at = None
        self.dropped_frames = 0

    def connect(self):
        with self.lock:
            if self.thread and self.thread.is_alive():
                return False
            self.stop_event = threading.Event()
            self.status, self.error, self.frame = "connecting", None, None
            self.sample_times.clear()
            self.thread = threading.Thread(target=self._run, daemon=True)
            self.thread.start()
            return True

    def _run(self):
        bus = self.bus_factory(self.port)
        try:
            bus.open()
            consecutive_errors = 0
            next_sample = self.clock()
            while not self.stop_event.is_set():
                try:
                    frame = bus.read_frame()
                except ReadOnlyBusCommunicationError as error:
                    consecutive_errors += 1
                    with self.lock:
                        self.dropped_frames += 1
                        self.status, self.error = "recovering", "通信校验或回应缺失，已丢弃本帧，正在重新只读预检"
                    print(json.dumps({"event": "frame_dropped", "error": str(error), "consecutive": consecutive_errors}, ensure_ascii=False), flush=True)
                    if consecutive_errors >= 3:
                        raise
                    bus.close()
                    if self.stop_event.wait(0.25):
                        break
                    # Full passive listening and identity checks; never take over a
                    # busy endpoint or discard another host's traffic in-place.
                    bus.open()
                    next_sample = self.clock()
                    continue
                consecutive_errors = 0
                with self.lock:
                    self.frame = frame
                    self.sequence += 1
                    self.sample_times.append(frame["monotonic"])
                    self.observed_at = datetime.now(timezone.utc).isoformat()
                    self.status = "live"
                    self.error = None
                # Keep a fixed cadence. Relative per-frame sleeps accumulate Mac
                # timer coalescing delays and reduce a 30 Hz target to ~20 Hz.
                # If a read overruns, start the next one without a catch-up burst.
                next_sample = max(next_sample + 1 / self.hz, self.clock())
                self.stop_event.wait(max(0, next_sample - self.clock()))
        except Exception as error:
            with self.lock:
                self.status, self.error = "error", str(error)
            print(json.dumps({"event": "read_stopped", "error": str(error)}, ensure_ascii=False), flush=True)
        finally:
            bus.close()
            with self.lock:
                if self.stop_event.is_set():
                    self.status = "disconnected"

    def disconnect(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=4)
        with self.lock:
            if not self.thread or not self.thread.is_alive():
                self.status = "disconnected"

    def snapshot(self):
        with self.lock:
            frame = self.frame
            age = max(0, self.clock() - frame["monotonic"]) if frame else None
            fresh = self.status == "live" and age is not None and age <= MAX_FRAME_AGE_SECONDS
            times = self.sample_times
            span = times[-1] - times[0] if len(times) > 1 else 0
            return {
                "app": APP, "source": "u2d2", "port": self.port,
                "status": "stale" if self.status == "live" and not fresh else self.status,
                "fresh": fresh, "error": self.error, "sequence": self.sequence,
                "observed_at": self.observed_at,
                "dropped_frames": self.dropped_frames,
                "age_ms": round(age * 1000, 1) if age is not None else None,
                "hz": round((len(times) - 1) / span, 1) if span > 0 else 0,
                "joints": frame["joints"] if frame else None,
                "motors": frame["motors"] if frame else [],
                "battery_v": round(sum(m["voltage_v"] for m in frame["motors"]) / 15, 2)
                if frame and len(frame["motors"]) == 15 and all("voltage_v" in m for m in frame["motors"]) else None,
                "telemetry_note": "逐台电压、电流、温度与角度来自 U2D2 的同一只读采样。",
                "body_orientation_measured": False, "hardware_control_writes": 0,
            }


def detect_u2d2():
    ports = [p for p in list_ports() if p["vid"] == 0x0403 and p["device"].startswith("/dev/cu.")]
    return ports[0]["device"] if len(ports) == 1 else None


class SourceManager:
    def __init__(self, u2d2, radxa, source):
        self.readers = {"u2d2": u2d2, "radxa": radxa}
        self.source = source
        self.lock = threading.Lock()

    def snapshot(self):
        with self.lock:
            return self.readers[self.source].snapshot()

    def connect(self):
        with self.lock:
            if self.source == "u2d2":
                port = detect_u2d2()
                if not port:
                    raise ValueError("未找到唯一 U2D2；瑞莎来源仍可使用")
                self.readers["u2d2"].port = port
            self.readers[self.source].connect()
            return self.readers[self.source].snapshot()

    def disconnect(self):
        with self.lock:
            self.readers[self.source].disconnect()
            return self.readers[self.source].snapshot()

    def switch(self, source):
        if source not in self.readers:
            raise ValueError("未知数据来源")
        with self.lock:
            if source == self.source:
                return self.readers[source].snapshot()
            if source == "u2d2":
                port = detect_u2d2()
                if not port:
                    raise ValueError("未找到唯一 U2D2；当前数据来源未改变")
                self.readers["u2d2"].port = port
            self.readers[self.source].disconnect()
            self.source = source
            self.readers[source].connect()
            return self.readers[source].snapshot()

    def close(self):
        for reader in self.readers.values():
            reader.disconnect()


def video_available():
    return camera_status()["available"]


def make_handler(reader, model_file, web_port, video=None):
    folder = Path(__file__).resolve().parent
    files = {
        "/": (folder / "index.html", "text/html; charset=utf-8"),
        "/app.js": (folder / "app.js", "text/javascript; charset=utf-8"),
        "/camera.js": (folder / "camera.js", "text/javascript; charset=utf-8"),
        "/duck-view.js": (ROOT / "tools/microduck-observer/duck-view.js", "text/javascript; charset=utf-8"),
        "/duck.bin": (model_file, "application/octet-stream"),
    }
    hosts = {f"127.0.0.1:{web_port}", f"localhost:{web_port}"}

    class Handler(BaseHTTPRequestHandler):
        def reply(self, status, data, content_type="application/json; charset=utf-8"):
            body = data if isinstance(data, bytes) else json.dumps(data, ensure_ascii=False, allow_nan=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self' ws://127.0.0.1:18443; media-src 'self' blob:; frame-ancestors 'none'")
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def allowed(self):
            return self.headers.get("Host") in hosts

        def do_GET(self):
            if not self.allowed():
                return self.reply(403, {"error": "Local host required"})
            path = urlsplit(self.path).path
            if path == "/api/state":
                return self.reply(200, reader.snapshot())
            if path == "/api/video":
                return self.reply(200, video.snapshot() if video else camera_status())
            if path in files:
                source, mime = files[path]
                return self.reply(200, source.read_bytes(), mime)
            self.reply(404, {"error": "Not found"})

        def do_POST(self):
            origin = self.headers.get("Origin")
            if not self.allowed() or origin != f"http://{self.headers.get('Host')}":
                return self.reply(403, {"error": "Same-origin request required"})
            path = urlsplit(self.path).path
            if path == "/api/disconnect":
                state = reader.disconnect()
            elif path == "/api/video/start":
                if video is None:
                    return self.reply(503, {"error": "视频管理器不可用"})
                video.start()
                return self.reply(202, {"starting": True})
            elif path == "/api/connect":
                try:
                    state = reader.connect()
                except ValueError as error:
                    return self.reply(409, {"error": str(error)})
            elif path == "/api/source":
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    if not 0 < length <= 64:
                        raise ValueError("无效的数据来源请求")
                    request = json.loads(self.rfile.read(length))
                    if not isinstance(request, dict) or set(request) != {"source"}:
                        raise ValueError("无效的数据来源请求")
                    state = reader.switch(request["source"])
                except (ValueError, TypeError, json.JSONDecodeError) as error:
                    return self.reply(409, {"error": str(error)})
            else:
                return self.reply(404, {"error": "Not found"})
            self.reply(200, state)

        def log_message(self, *_args):
            pass

    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--serial", help="U2D2 serial device; auto-select the single FTDI device")
    parser.add_argument("--port", type=int, default=18091)
    parser.add_argument("--hz", type=float, default=30.0)
    parser.add_argument("--disconnected", action="store_true", help="Open the UI without opening any serial device")
    parser.add_argument("--source", choices=("auto", "u2d2", "radxa"), default="auto")
    args = parser.parse_args()
    if not math.isfinite(args.hz) or not 1 <= args.hz <= 40:
        parser.error("--hz must be between 1 and 40")
    serial_port = args.serial or detect_u2d2()
    source = ("u2d2" if serial_port else "radxa") if args.source == "auto" else args.source
    if source == "u2d2" and not serial_port:
        parser.error("未找到唯一 U2D2；请使用 --serial 指定串口")
    model_file = ROOT / "work/microduck-observer-assets/duck-web-mouth-v2.bin"
    if not model_file.is_file():
        parser.error(f"Missing model: {model_file}")
    reader = SourceManager(Reader(serial_port, args.hz), RadxaReader(), source)
    video = LiveVideoManager()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(reader, model_file, args.port, video))
    server.daemon_threads = True

    def shutdown(_signum, _frame):
        reader.readers[reader.source].stop_event.set()
        threading.Thread(target=server.shutdown, daemon=True).start()

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT, shutdown)
    if not args.disconnected:
        reader.connect()
    print(json.dumps({"app": APP, "url": f"http://127.0.0.1:{args.port}/", "source": source, "serial": serial_port}, ensure_ascii=False), flush=True)
    try:
        server.serve_forever(poll_interval=0.1)
    finally:
        video.close()
        reader.close()
        server.server_close()


if __name__ == "__main__":
    main()
