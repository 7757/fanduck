"""On-demand, camera-only live view for the unified local dashboard."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import threading
import time
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[2]
START = ROOT / "scripts/start_microduck_live_video.sh"
STOP = ROOT / "scripts/stop_microduck_live_video.sh"
STATUS_URL = "http://127.0.0.1:18092/status"
IDLE_SECONDS = 45


def camera_status() -> dict:
    if os.environ.get("MICRODUCK_ENABLE_CAMERA") != "1":
        return {"available": False, "phase": "disabled", "reason": "camera-opt-in-required",
                "error": "相机默认关闭；确认安全后显式启用。"}
    try:
        with urlopen(STATUS_URL, timeout=0.4) as response:
            status = json.load(response)
        guard = status.get("guard") or {}
        units = status.get("units") or {}
        running = (
            status.get("ok") is True
            and guard.get("phase") == "running"
            and units.get("media") == "active"
            and units.get("camera_3a") == "active"
        )
        return {
            "available": bool(running),
            "phase": guard.get("phase", "unavailable"),
            "reason": guard.get("reason", "unavailable"),
            "temperature_c": status.get("max_celsius"),
            "elapsed_seconds": guard.get("elapsed_seconds"),
            "limit_seconds": guard.get("limit_seconds"),
        }
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return {"available": False, "phase": "unavailable", "reason": "unavailable"}


class LiveVideoManager:
    def __init__(self, run=subprocess.run, clock=time.monotonic):
        self.run = run
        self.clock = clock
        self.lock = threading.Lock()
        self.start_thread: threading.Thread | None = None
        self.stop_event = threading.Event()
        self.last_view = None
        self.error = None
        self.watcher = threading.Thread(target=self._watch_idle, daemon=True)
        self.watcher.start()

    def snapshot(self):
        with self.lock:
            self.last_view = self.clock()
            starting = self.start_thread is not None and self.start_thread.is_alive()
            error = self.error
        state = camera_status()
        if not state["available"] and starting:
            state["phase"] = "starting"
        if not state["available"] and error:
            state["error"] = error
        return state

    def start(self):
        with self.lock:
            self.last_view = self.clock()
            if self.start_thread and self.start_thread.is_alive():
                return
            self.error = None
            self.start_thread = threading.Thread(target=self._start, daemon=True)
            self.start_thread.start()

    def _start(self):
        try:
            result = self.run(["/bin/bash", str(START)], capture_output=True, text=True, timeout=70)
            if result.returncode:
                lines = (result.stderr or result.stdout).splitlines()
                useful = next((line for line in reversed(lines) if line.startswith(
                    ("相机", "本机", "主控", "视频", "无法", "头部"))), None)
                raise RuntimeError(useful or "相机启动失败；运行 microduck start 可查看详细原因。")
        except (OSError, subprocess.SubprocessError, RuntimeError) as error:
            with self.lock:
                self.error = str(error)

    def _watch_idle(self):
        while not self.stop_event.wait(5):
            with self.lock:
                expired = self.last_view is not None and self.clock() - self.last_view > IDLE_SECONDS
                starting = self.start_thread is not None and self.start_thread.is_alive()
                if expired and not starting:
                    self.last_view = None
            if expired and not starting:
                self._stop()

    def _stop(self):
        try:
            self.run(["/bin/bash", str(STOP)], capture_output=True, text=True, timeout=25)
        except (OSError, subprocess.SubprocessError):
            pass  # The board-side session has its own hard time limit.

    def close(self):
        self.stop_event.set()
        if self.start_thread and self.start_thread.is_alive():
            self.start_thread.join(timeout=70)
        self._stop()
        self.watcher.join(timeout=1)
