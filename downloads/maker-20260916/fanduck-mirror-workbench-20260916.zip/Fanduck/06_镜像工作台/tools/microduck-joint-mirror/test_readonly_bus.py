"""Real SDK framing over a fake serial endpoint; never opens a device."""

import math
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from dynamixel_sdk import PacketHandler

import readonly_bus as rb


def status_packet(motor_id, payload, error=0):
    packet = list(b"\xff\xff\xfd\x00") + [motor_id]
    packet += list((len(payload) + 4).to_bytes(2, "little"))
    packet += [0x55, error] + list(payload) + [0, 0]
    handler = PacketHandler(2.0)
    packet = handler.addStuffing(packet)
    crc = handler.updateCRC(0, packet, len(packet) - 2)
    packet[-2:] = list(crc.to_bytes(2, "little"))
    return bytes(packet)


class FakeSerial:
    def __init__(self):
        self.rx = bytearray()
        self.writes = []
        self.closed = False
        self.exclusive = False
        self.positions = {motor_id: 2048 for motor_id in rb.JOINT_IDS}
        self.offsets = {motor_id: -motor_id for motor_id in rb.JOINT_IDS}
        self.models = {motor_id: rb.MODEL_NUMBER for motor_id in rb.JOINT_IDS}
        self.torque = {}
        self.errors = {}
        self.voltages = {motor_id: 51 for motor_id in rb.JOINT_IDS}
        self.temperatures = {motor_id: 26 for motor_id in rb.JOINT_IDS}
        self.currents = {motor_id: 0 for motor_id in rb.JOINT_IDS}
        self.transform_frames = lambda frames: frames
        self.on_sync = lambda: None
        self.fail_next_tx = False

    def fileno(self):
        return 123456

    @property
    def in_waiting(self):
        return len(self.rx)

    def reset_input_buffer(self):
        self.rx.clear()

    def close(self):
        self.closed = True

    def read(self, length):
        result = bytes(self.rx[:length])
        del self.rx[:length]
        return result

    def write(self, packet):
        self.writes.append(bytes(packet))
        if self.fail_next_tx:
            self.fail_next_tx = False
            return len(packet) - 1
        instruction = packet[7]
        if instruction == 0x02:
            motor_id = packet[4]
            address = int.from_bytes(packet[8:10], "little")
            if address == 0:
                payload = self.models[motor_id].to_bytes(2, "little")
            elif address == 20:
                payload = self.offsets[motor_id].to_bytes(4, "little", signed=True)
            else:
                raise AssertionError(f"Unexpected register read {address}")
            self.rx.extend(status_packet(motor_id, payload))
        elif instruction == 0x82:
            assert int.from_bytes(packet[8:10], "little") == 64
            assert int.from_bytes(packet[10:12], "little") == rb.FRAME_LENGTH
            assert tuple(packet[12:-2]) == rb.JOINT_IDS
            self.on_sync()
            frames = []
            for motor_id in rb.JOINT_IDS:
                payload = bytearray(rb.FRAME_LENGTH)
                payload[0] = self.torque.get(motor_id, 0)
                payload[6] = self.errors.get(motor_id, 0)
                payload[62:64] = self.currents[motor_id].to_bytes(2, "little", signed=True)
                payload[68:72] = self.positions[motor_id].to_bytes(4, "little", signed=True)
                payload[80:82] = self.voltages[motor_id].to_bytes(2, "little")
                payload[82] = self.temperatures[motor_id]
                frames.append((motor_id, payload, 0))
            for motor_id, payload, error in self.transform_frames(frames):
                self.rx.extend(status_packet(motor_id, payload, error))
        else:
            raise AssertionError(f"Non-read instruction reached serial endpoint: {instruction}")
        return len(packet)


class ReadOnlyBusTests(unittest.TestCase):
    def setUp(self):
        self.serial = FakeSerial()
        self.serial_patch = patch("dynamixel_sdk.port_handler.serial.Serial", return_value=self.serial)
        self.serial_constructor = self.serial_patch.start()
        self.ioctl_patch = patch.object(rb.fcntl, "ioctl")
        self.ioctl = self.ioctl_patch.start()
        self.addCleanup(self.serial_patch.stop)
        self.addCleanup(self.ioctl_patch.stop)
        self.bus = rb.ReadOnlyBus("/dev/fake-u2d2")
        quiet_patch = patch.object(self.bus, "_require_quiet_bus")
        self.quiet_check = quiet_patch.start()
        self.addCleanup(quiet_patch.stop)
        self.addCleanup(self.bus.close)

    def test_enumeration_never_opens_a_port(self):
        item = SimpleNamespace(device="/dev/cu.example", description="FTDI", serial_number="ABC", vid=1027, pid=24596)
        with patch.object(rb.serial_ports, "comports", return_value=[item]):
            self.assertEqual(rb.list_ports(), [vars(item)])
        self.serial_constructor.assert_not_called()

    def test_open_only_reads_identity_and_offsets_after_one_exclusive_open(self):
        self.bus.open()
        self.serial_constructor.assert_called_once()
        self.assertEqual(self.serial_constructor.call_args.kwargs["baudrate"], 1_000_000)
        self.assertTrue(self.serial.exclusive)
        self.assertEqual(self.serial.timeout, 0.010)
        self.quiet_check.assert_called_once()
        self.ioctl.assert_called_once_with(123456, rb.termios.TIOCEXCL)
        self.assertEqual(len(self.serial.writes), 30)
        self.assertEqual({packet[7] for packet in self.serial.writes}, {0x02})
        self.assertEqual([int.from_bytes(p[8:10], "little") for p in self.serial.writes], [0, 20] * 15)

    def test_complete_frame_preserves_order_signed_multiturn_and_offset(self):
        values = [-4096, -1, 0, 2048, 4096, 8192] + [2048] * 9
        self.serial.positions.update(zip(rb.JOINT_IDS, values))
        self.serial.voltages[30] = 49
        self.serial.temperatures[30] = 33
        self.serial.currents[30] = -42
        self.bus.open()
        frame = self.bus.read_frame()
        self.assertEqual([motor["id"] for motor in frame["motors"]], list(rb.JOINT_IDS))
        self.assertEqual([motor["raw"] for motor in frame["motors"]], values)
        self.assertEqual([motor["offset"] for motor in frame["motors"]], [-i for i in rb.JOINT_IDS])
        neck = next(motor for motor in frame["motors"] if motor["id"] == 30)
        self.assertEqual((neck["voltage_v"], neck["temperature_c"], neck["current_ma"]), (4.9, 33, -42))
        self.assertTrue(all(motor["voltage_v"] == 5.1 for motor in frame["motors"] if motor["id"] != 30))
        for raw, angle in zip(values, frame["joints"]):
            self.assertAlmostEqual(angle, raw * math.tau / 4096 - math.pi)
        self.assertIsInstance(frame["monotonic"], float)
        self.assertEqual(self.serial.writes[-1][7], 0x82)

    def test_native_stuffing_is_accepted_without_truncating_position(self):
        raw = int.from_bytes(b"\xff\xff\xfd\x00", "little", signed=True)
        self.serial.positions[23] = raw
        self.bus.open()
        frame = self.bus.read_frame()
        self.assertEqual(next(m for m in frame["motors"] if m["id"] == 23)["raw"], raw)

    def test_torque_on_invalidates_whole_frame(self):
        self.bus.open()
        self.serial.torque[23] = 1
        with self.assertRaisesRegex(rb.ReadOnlyBusError, "ID 23: torque"):
            self.bus.read_frame()

    def test_hardware_error_invalidates_whole_frame(self):
        self.bus.open()
        self.serial.errors[13] = 0x20
        with self.assertRaisesRegex(rb.ReadOnlyBusError, "ID 13: hardware error"):
            self.bus.read_frame()

    def test_status_error_is_not_discarded(self):
        self.bus.open()
        self.serial.transform_frames = lambda frames: [(i, p, 0x80 if i == 21 else e) for i, p, e in frames]
        with self.assertRaisesRegex(rb.ReadOnlyBusError, "ID 21: status error"):
            self.bus.read_frame()

    def test_duplicate_id_is_rejected(self):
        self.bus.open()
        self.serial.transform_frames = lambda frames: [frames[0], frames[0]] + frames[2:]
        with self.assertRaisesRegex(rb.ReadOnlyBusError, "Duplicate ID 20"):
            self.bus.read_frame()

    def test_missing_id_is_rejected_without_previous_frame_fallback(self):
        self.bus.open()
        self.bus.read_frame()
        self.serial.transform_frames = lambda frames: frames[:-1]
        with self.assertRaisesRegex(rb.ReadOnlyBusError, r"waiting for IDs \[14\]"):
            self.bus.read_frame()

    def test_short_status_cannot_supply_crc_bytes_as_position_data(self):
        self.bus.open()
        self.serial.transform_frames = lambda frames: [(i, p[:-1] if i == 24 else p, e) for i, p, e in frames]
        with self.assertRaisesRegex(rb.ReadOnlyBusError, "ID 24: wrong status length"):
            self.bus.read_frame()

    def test_corrupt_crc_is_rejected_by_real_sdk(self):
        self.bus.open()
        original_write = self.serial.write

        def corrupt_response(packet):
            written = original_write(packet)
            self.serial.rx[82] ^= 1  # Corrupt the first status packet before SDK CRC verification.
            return written

        with patch.object(self.serial, "write", side_effect=corrupt_response):
            with self.assertRaisesRegex(rb.ReadOnlyBusError, "Incorrect status packet"):
                self.bus.read_frame()

    def test_wrong_model_closes_port_without_control_write(self):
        self.serial.models[22] = 1190
        with self.assertRaisesRegex(rb.ReadOnlyBusError, "ID 22: model 1190"):
            self.bus.open()
        self.assertTrue(self.serial.closed)
        self.assertTrue(all(packet[7] == 0x02 for packet in self.serial.writes))

    def test_tx_failure_cannot_return_cached_success(self):
        self.bus.open()
        previous = self.bus.read_frame()
        self.serial.positions[20] = 1024
        self.serial.fail_next_tx = True
        with self.assertRaisesRegex(rb.ReadOnlyBusError, "Synchronous read request"):
            self.bus.read_frame()
        latest = self.bus.read_frame()
        self.assertNotEqual(latest["joints"][0], previous["joints"][0])

    def test_acquisition_that_is_already_stale_is_rejected(self):
        self.bus.open()
        clock = [100.0]
        self.serial.on_sync = lambda: clock.__setitem__(0, clock[0] + 0.3)
        with patch.object(rb.time, "monotonic", side_effect=lambda: clock[0]):
            with self.assertRaisesRegex(rb.ReadOnlyBusError, "Stale read"):
                self.bus.read_frame()

    def test_output_boundary_blocks_control_table_write(self):
        port = rb._ReadOnlyPortHandler("/dev/fake-u2d2")
        port.ser = self.serial
        # A complete, correctly sized Protocol 2 WRITE packet to Torque Enable.
        packet = bytearray(b"\xff\xff\xfd\x00\x14\x06\x00\x03\x40\x00\x01\x00\x00")
        for instruction in (0x03, 0x04, 0x05, 0x06, 0x08, 0x83, 0x93):
            with self.subTest(instruction=instruction):
                packet[7] = instruction
                with self.assertRaisesRegex(rb.ReadOnlyBusError, "rejected instruction"):
                    port.writePort(packet)
        self.assertEqual(self.serial.writes, [])

    def test_unsolicited_traffic_stops_before_transmission(self):
        self.bus.open()
        before = len(self.serial.writes)
        self.serial.rx.extend(status_packet(200, b"\x00" * 4))
        with self.assertRaisesRegex(rb.ReadOnlyBusError, "非本次请求"):
            self.bus.read_frame()
        self.assertEqual(len(self.serial.writes), before)

    def test_passive_startup_rejects_other_host_without_sending(self):
        self.bus.open()
        before = len(self.serial.writes)
        self.serial.rx.extend(status_packet(200, b"\x00" * 4))
        clock = iter(index * 0.01 for index in range(1000))
        with patch.object(rb.time, "monotonic", side_effect=lambda: next(clock)), patch.object(rb.time, "sleep"):
            with self.assertRaisesRegex(rb.ReadOnlyBusError, "总线上已有数据"):
                rb.ReadOnlyBus._require_quiet_bus(self.bus)
        self.assertEqual(len(self.serial.writes), before)


if __name__ == "__main__":
    unittest.main()
