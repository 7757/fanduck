#!/usr/bin/env python3
"""Bake Pollen's full-resolution MJCF/STL visuals for the browser observer.

This deliberately differs from Pollen's ``robotctl`` bake: the terminal renderer
reduces the CAD-derived mesh to a few thousand triangles, while the Mac browser has
a GPU and can retain the official simulation geometry.  The generated file contains
only visual meshes, transforms, colours and the kinematic tree; it contains no robot
control data and never runs on the Radxa.
"""

from __future__ import annotations

import argparse
import math
import struct
import xml.etree.ElementTree as ET
from pathlib import Path


MAGIC = b"DHD2"
FORMAT_VERSION = 2

# Runtime wire order. The public MJCF welds the mouth. It remains unused by default;
# the U2D2 mirror explicitly opts into the local CAD-derived visual articulation.
JOINT_NAMES = [
    "left_hip_yaw",
    "left_hip_roll",
    "left_hip_pitch",
    "left_knee",
    "left_ankle",
    "neck_pitch",
    "head_pitch",
    "head_yaw",
    "head_roll",
    "mouth",
    "right_hip_yaw",
    "right_hip_roll",
    "right_hip_pitch",
    "right_knee",
    "right_ankle",
]

# These official simulation parts sit inside closed shells. Drawing them makes the
# outside look broken when depth precision or transparency differs between renderers.
HIDDEN = {
    "np_f970",
    "pcb__raspberry_pi_zero_2_w",
    "elec_rpi_robot_hat_pcb",
    "power_support",
    "banana_pcb_locker",
    "motor_support",
}


def floats(text: str | None, default: str) -> tuple[float, ...]:
    return tuple(float(value) for value in (text or default).split())


def load_indexed_stl(path: Path) -> tuple[list[bytes], list[int]]:
    """Read a binary STL and weld byte-identical vertices without simplifying it."""
    data = path.read_bytes()
    if len(data) < 84:
        raise SystemExit(f"{path}: STL is shorter than its binary header")
    (triangle_count,) = struct.unpack_from("<I", data, 80)
    if len(data) != 84 + triangle_count * 50:
        raise SystemExit(f"{path}: expected a binary STL with {triangle_count} facets")

    vertices: list[bytes] = []
    indices: list[int] = []
    vertex_ids: dict[bytes, int] = {}
    for triangle in range(triangle_count):
        corner_start = 84 + triangle * 50 + 12
        for corner in range(3):
            packed = data[corner_start + corner * 12 : corner_start + (corner + 1) * 12]
            index = vertex_ids.get(packed)
            if index is None:
                index = len(vertices)
                vertex_ids[packed] = index
                vertices.append(packed)
            indices.append(index)
    return vertices, indices


def build(mjcf_path: Path, *, articulate_mouth: bool = False) -> tuple[bytes, dict[str, int]]:
    root = ET.parse(mjcf_path).getroot()
    compiler = root.find("compiler")
    mesh_dir = mjcf_path.parent / (compiler.get("meshdir", ".") if compiler is not None else ".")

    materials = {
        material.get("name"): floats(material.get("rgba"), "0.5 0.5 0.5 1")[:3]
        for material in root.iter("material")
    }

    meshes: dict[str, tuple[list[bytes], list[int]]] = {}

    def mesh_index(name: str) -> int:
        if name not in meshes:
            meshes[name] = load_indexed_stl(mesh_dir / f"{name}.stl")
        return list(meshes).index(name)

    bodies: list[dict[str, object]] = []
    parts: list[dict[str, object]] = []

    def walk(body: ET.Element, parent: int) -> None:
        body_index = len(bodies)
        joint = body.find("joint")
        joint_name = joint.get("name") if joint is not None else None
        bodies.append(
            {
                "parent": parent,
                "joint": JOINT_NAMES.index(joint_name) if joint_name in JOINT_NAMES else -1,
                "position": floats(body.get("pos"), "0 0 0"),
                "quaternion": floats(body.get("quat"), "1 0 0 0"),
                "axis": floats(joint.get("axis"), "0 0 1") if joint is not None else (0.0, 0.0, 0.0),
            }
        )

        mouth_body = None
        mouth_pivot = (0.003, 0.0, -0.018)
        if articulate_mouth and body.get("name") == "jaw_soft":
            # Display-only derivative of the welded walk MJCF. xl330_10's
            # shaft and the opposite bearing lie along head-local Y at this
            # X/Z location. Positive rotation lowers the beak (-X is down).
            # The official runtime calls -5 degrees closed, +30 degrees open;
            # the welded CAD pose is used as that closed reference. This is
            # visual mapping, not an encoder calibration or a servo command.
            motor = body.find("geom[@mesh='xl330'][@pos='0.003 0.0255 -0.018']")
            if motor is None or not {"jaw", "jaw_soft", "soft_mouth_top"}.issubset(g.get("mesh") for g in body.findall("geom")):
                raise ValueError("Head CAD changed; recheck the display mouth pivot")
            mouth_body = len(bodies)
            half_angle = math.radians(5) / 2
            bodies.append({
                "parent": body_index, "joint": JOINT_NAMES.index("mouth"),
                "position": mouth_pivot,
                "quaternion": (math.cos(half_angle), 0.0, math.sin(half_angle), 0.0),
                "axis": (0.0, 1.0, 0.0),
            })

        for geom in body.findall("geom"):
            if geom.get("class") != "visual" or geom.get("type") != "mesh":
                continue
            mesh_name = geom.get("mesh")
            if not mesh_name or mesh_name in HIDDEN:
                continue
            colour = materials.get(geom.get("material"), (0.5, 0.5, 0.5))
            moves_with_mouth = mouth_body is not None and mesh_name in {"jaw", "jaw_soft"}
            position = floats(geom.get("pos"), "0 0 0")
            if moves_with_mouth:
                position = tuple(value - pivot for value, pivot in zip(position, mouth_pivot))
            parts.append(
                {
                    "body": mouth_body if moves_with_mouth else body_index,
                    "mesh": mesh_index(mesh_name),
                    "colour": colour,
                    "position": position,
                    "quaternion": floats(geom.get("quat"), "1 0 0 0"),
                }
            )
        for child in body.findall("body"):
            walk(child, body_index)

    worldbody = root.find("worldbody")
    if worldbody is None:
        raise SystemExit(f"{mjcf_path}: missing <worldbody>")
    for top_level_body in worldbody.findall("body"):
        walk(top_level_body, -1)

    # Final zero is reserved padding so every float/index array starts 4-byte aligned
    # and can be exposed to WebGL without copying in JavaScript.
    output = bytearray(
        struct.pack("<4sIHHHH", MAGIC, FORMAT_VERSION, len(meshes), len(bodies), len(parts), 0)
    )
    for vertices, indices in meshes.values():
        output += struct.pack("<II", len(vertices), len(indices) // 3)
        output += b"".join(vertices)
        output += struct.pack(f"<{len(indices)}I", *indices)
    for body in bodies:
        output += struct.pack("<hh", int(body["parent"]), int(body["joint"]))
        output += struct.pack("<3f", *body["position"])
        output += struct.pack("<4f", *body["quaternion"])
        output += struct.pack("<3f", *body["axis"])
    for part in parts:
        rgb = tuple(round(max(0.0, min(1.0, value)) * 255) for value in part["colour"])
        output += struct.pack("<HHBBBB", int(part["body"]), int(part["mesh"]), *rgb, 0)
        output += struct.pack("<3f", *part["position"])
        output += struct.pack("<4f", *part["quaternion"])

    unique_triangles = sum(len(indices) // 3 for _, indices in meshes.values())
    drawn_triangles = sum(len(list(meshes.values())[int(part["mesh"])][1]) // 3 for part in parts)
    stats = {
        "meshes": len(meshes),
        "bodies": len(bodies),
        "parts": len(parts),
        "unique_triangles": unique_triangles,
        "drawn_triangles": drawn_triangles,
    }
    return bytes(output), stats


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mjcf", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mouth", action="store_true", help="Add the local display-only jaw articulation")
    args = parser.parse_args()

    mjcf = args.mjcf.resolve(strict=True)
    payload, stats = build(mjcf, articulate_mouth=args.mouth)
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.is_file() and output.read_bytes() == payload:
        action = "unchanged"
    else:
        temporary = output.with_suffix(output.suffix + ".tmp")
        temporary.write_bytes(payload)
        temporary.replace(output)
        action = "written"

    print(
        f"{output}: {action}, {len(payload) / (1024 * 1024):.1f} MiB, "
        f"{stats['meshes']} meshes, {stats['parts']} parts, "
        f"{stats['drawn_triangles']:,} instanced triangles"
    )


if __name__ == "__main__":
    main()
