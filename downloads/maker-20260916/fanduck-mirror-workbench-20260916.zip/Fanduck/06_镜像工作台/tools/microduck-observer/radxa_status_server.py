#!/usr/bin/env python3
"""Loopback-only status endpoint for the Microduck read-only observer."""

from __future__ import annotations

import argparse
import json
import subprocess
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit


UNITS = {
    "media": "microduck-observe-media.service",
    "tof": "microduck-observe-tof.service",
    "camera_3a": "microduck-observe-rkaiq.service",
    "guard": "microduck-observe-guard.service",
}
LIVE_UNITS = {
    "media": "microduck-live-video-media.service",
    "camera_3a": "microduck-live-video-3a.service",
    "guard": "microduck-live-video-guard.service",
}


def thermal_zones() -> list[dict[str, object]]:
    zones: list[dict[str, object]] = []
    for directory in sorted(Path("/sys/class/thermal").glob("thermal_zone*")):
        try:
            raw = int((directory / "temp").read_text().strip())
            name = (directory / "type").read_text().strip()
        except (OSError, ValueError):
            continue
        if raw <= 0:
            continue
        zones.append({"name": name, "millidegrees": raw, "celsius": round(raw / 1000, 3)})
    return zones


def unit_states(units: dict[str, str] = UNITS) -> dict[str, str]:
    result = subprocess.run(
        ["systemctl", "is-active", *units.values()],
        check=False,
        capture_output=True,
        text=True,
        timeout=2,
    )
    lines = result.stdout.splitlines()
    return {
        key: lines[index].strip() if index < len(lines) else "unknown"
        for index, key in enumerate(units)
    }


def guard_state(path: Path) -> dict[str, object]:
    try:
        value = json.loads(path.read_text())
    except (OSError, ValueError, json.JSONDecodeError):
        return {"reason": "starting", "running": False}
    return value if isinstance(value, dict) else {"reason": "unknown", "running": False}


def make_handler(args: argparse.Namespace):
    class StatusHandler(BaseHTTPRequestHandler):
        server_version = "MicroduckObserverStatus/1"

        def do_GET(self) -> None:  # noqa: N802 - BaseHTTPRequestHandler API
            if urlsplit(self.path).path != "/status":
                self.send_error(404)
                return

            try:
                zones = thermal_zones()
                units = unit_states(LIVE_UNITS if args.profile == "live" else UNITS)
                state = guard_state(Path(args.state_file))
                maximum = max((int(zone["millidegrees"]) for zone in zones), default=None)
                payload = {
                    "ok": maximum is not None,
                    "sampled_at_ms": int(time.time() * 1000),
                    "zones": zones,
                    "max_celsius": round(maximum / 1000, 3) if maximum is not None else None,
                    "warning_celsius": args.warning_temp_c,
                    "stop_celsius": args.stop_temp_c,
                    "units": units,
                    "guard": state,
                }
                body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1:18090")
                self.end_headers()
                self.wfile.write(body)
            except (OSError, subprocess.SubprocessError) as error:
                body = json.dumps({"ok": False, "error": str(error)}).encode()
                self.send_response(503)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1:18090")
                self.end_headers()
                self.wfile.write(body)

        def log_message(self, _format: str, *_args: object) -> None:
            return

    return StatusHandler


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18081)
    parser.add_argument("--state-file", default="/run/microduck-observer-state.json")
    parser.add_argument("--profile", choices=("observer", "live"), default="observer")
    parser.add_argument("--warning-temp-c", type=int, default=75)
    parser.add_argument("--stop-temp-c", type=int, default=90)
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), make_handler(args))
    server.serve_forever(poll_interval=0.5)


if __name__ == "__main__":
    main()
