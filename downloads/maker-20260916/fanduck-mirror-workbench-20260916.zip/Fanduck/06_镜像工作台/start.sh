#!/usr/bin/env bash
set -euo pipefail
MIRROR_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
MIRROR_PYTHON="${MICRODUCK_PYTHON:-$MIRROR_ROOT/.venv/bin/python}"
if [[ ! -x "$MIRROR_PYTHON" ]]; then
  echo '请先按 README 创建 .venv 并安装 requirements.txt。' >&2
  exit 1
fi
# Start a local disconnected viewer. A deliberate UI connect is required.
exec "$MIRROR_PYTHON" "$MIRROR_ROOT/tools/microduck-joint-mirror/server.py" --disconnected "$@"
