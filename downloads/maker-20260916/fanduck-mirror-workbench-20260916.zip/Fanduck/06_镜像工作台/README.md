# Microduck 镜像工作台

本地查看鸭子的 3D 关节姿态、只读状态及可选相机画面。属于制作、装配和调试工具，不是官网或 Ducklink App。

**默认不连接设备，相机关闭。不要在不了解当前总线、扭矩和相机状态时点击连接或启用相机。** 本次只整理公开副本并做离线检查，未接真机。

## 收录内容

- tools/microduck-joint-mirror：本地网页、Python 服务、主控只读采集、U2D2 只读采集、相机管理和测试。
- tools/microduck-observer：镜像工作台实际使用的 3D 渲染器、模型生成器、主控温度状态服务；没有复制旧观察台整套产品。
- tools/microduck-live-video：可选相机配置、临时服务与温度保护。
- scripts：严格主机指纹校验的发现工具、相机启停脚本。
- work/microduck-observer-assets：所需的单个 3D 模型资源。

## 安装与查看

当前启动及视频脚本以 macOS 为目标，主控侧为已配置官方媒体栈的 Radxa Linux。需要 Python 3.10 或更高版本、OpenSSH；视频还依赖 macOS launchctl 与主控 systemd、mediad、RKAIQ/GStreamer。机载运行时和驱动不在本包。

终端进入本 README 所在的“06_镜像工作台”目录后：

~~~bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
bash start.sh
~~~

浏览器打开 http://127.0.0.1:18091/ 。这条启动命令只打开断开状态的本地工作台；没有真实采样时，模型显示不代表机器人当前姿态。Ctrl+C 退出。

不要为方便将监听地址改成公网或关闭同源校验。已有同端口工作台时，先按其原有正常路径停止，避免两套读取器争用。

## 连接自己的设备

| 环境变量 | 用途 / 默认值 |
| --- | --- |
| MICRODUCK_SSH_KEY | 你自己的私钥文件，默认 ~/.ssh/microduck_ed25519；本包不包含密钥 |
| MICRODUCK_KNOWN_HOSTS | 独立核验过的主机公钥文件，默认 ~/.ssh/microduck_known_hosts |
| MICRODUCK_HOST_ALIAS | known-hosts 中对应别名，默认 microduck |
| MICRODUCK_HOST_FINGERPRINT | 必填的 SHA256 主机指纹，无默认值 |
| MICRODUCK_HOST | 可选当前 IPv4 地址；指定地址仍须通过指纹校验 |
| MICRODUCK_ENABLE_CAMERA | 默认 0；只有显式为 1 才允许启动或停止本工作台的视频会话 |
| MICRODUCK_VIDEO_MINUTES | 可选视频会话时长，默认 10，范围 1–30 分钟 |
| MICRODUCK_PYTHON | 可选 Python 解释器；默认本目录 .venv/bin/python |

先通过你能信任的本机控制台取得主控 ED25519 公钥与指纹，再配置独立 known-hosts。不要将 ssh-keyscan 的未核对结果直接当作信任依据，也不要设 StrictHostKeyChecking=no。变量必须在启动工作台前设置。公开副本没有保留项目负责人的地址、指纹和密钥路径。

主控读取通过 root SSH 会话运行只读程序：robotd 正在运行时，只读其进程间通信（IPC）状态；停止时可能尝试独占读取空闲舵机总线。停止模式所需 dynamixel-sdk 和 pyserial 必须已存在于主控 Python 环境，本包不会自动安装。

使用 U2D2 时，必须确认主控退出同一 DATA 线、串口无人占用、总线静默、全 15 台舵机扭矩关闭且硬件错误为零；只读不是不发任何字节，它会发送查询包，但阻止运动/参数写指令。此工具不能替你完成安全断电或松力。

## 可选视频

相机仅在你确认硬件可用后显式启用。曾异常发热的相机必须隔离，不能借此再次通电。

启用视频会在主控创建临时相机服务及本地 SSH 隧道，不是纯文件读取；它不启停 robotd/padd，也不接管其他相机使用者。保留原有温度保护：低于 78°C 可开流；较热时等到不高于 75°C 稳定 10 秒；达到 90°C 暂停。无人观看约 45 秒停流，并保留会话最长时限。不要放宽这些门槛。

硬件变动前正常停机、断电；电压、正负极、限流和接线未确认前不要通电。出现异常发热、异味、声音或电流时停止并断电检查。镜像界面不是硬件急停。

## 离线测试

~~~bash
PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m unittest discover -s tools/microduck-joint-mirror -p 'test_*.py' -v
~~~

测试使用假串口和模拟状态，不连接真机。已验证的依赖版本为 dynamixel-sdk 4.0.5、pyserial 3.5。另做 JavaScript 与 Shell 语法检查；不据此宣称公开副本完成实机验收。

## 来源与本次改动

来源：本项目 tools/microduck-joint-mirror、tools/microduck-observer、tools/microduck-live-video 及对应 scripts；根项目无 Git 提交号，逐文件原始/公开副本 SHA-256 见本包 SOURCES.json。核对日期 2026-09-16。

只修改公开副本：个人 SSH 配置改为环境变量；去掉历史地址和临时 vendor 路径；相机改为显式启用；增加默认断开启动器、依赖清单和离线测试。串口写保护、数据过期、错误锁定和温度保护不变。原项目源码未改。

模型是 Pollen 官方公开仿真几何的浏览器显示衍生件，不是新的生产图纸：来源 https://github.com/pollen-robotics/microduck_rl ，提交 d424a0c899f6b33cbd3daeb279913134349c0b63；保持其 CC BY-SA-NC 非商业许可。许可原文依据保存在本包 LICENSES/官方模型许可依据。模型生成器已附；从头重建还需自行取得该锁定版本的完整 MJCF/STL，本包不夹带训练框架。

证据链：负责人指定公开镜像工作台 → 按调用关系筛选源码与依赖 → 公开副本脱敏、保留保护 → 离线测试和来源校验。本公开版本经负责人确认发布。
